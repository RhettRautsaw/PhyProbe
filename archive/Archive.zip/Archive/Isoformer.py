#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import pandas as pd
from dfply import *
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
except:
	print("Error: biopython module is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Script designed to take a Trinity or rnaSpades assembly and extract only the longest isoforms

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-f","--fasta",
					type=str,
					help="Trinity or rnaSpades assembly fasta file (default: None)")
parser.add_argument("-o","--output",
					type=str,
					default='.',
					help="Folder in which to export reduced assembly with only longest isoforms (default: %(default)s)")
args=parser.parse_args()

########################################
################# SETUP ################
########################################

fasta_name = os.path.abspath(args.fasta)
tmp = args.fasta.split("/")[-1]
sample = tmp.split(".")[0]
output = os.path.abspath(args.output)

########################################
################# START ################
########################################

print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')

fasta = list(SeqIO.parse(fasta_name,'fasta'))

names=[]
genes=[]
lengths=[]

for seq in fasta:
	if 'TRINITY' in seq.name:
		gene = seq.name.split('_i')[0] # TRINITY
	else:
		gene = seq.name.split('_')[-2] # rnaSPADES
	names.append(seq.name)
	genes.append(gene)
	lengths.append(len(seq))

df = {'transcript': names, 'gene': genes, 'length': lengths}
df = pd.DataFrame(df) 

genes=list(set(df.gene))

df2 = df.groupby('gene').agg('count')
df2 = list((df2 >> mask(X.transcript > 1)).index)

no_isoforms = []
for seq in fasta:
	if 'TRINITY' in seq.name:
		gene = seq.name.split('_i')[0] # TRINITY
	else:
		gene = seq.name.split('_')[-2] # rnaSPADES
	if gene not in df2:
		no_isoforms.append(seq)
	else:
		longest_isoform=(df >> mask(X.gene == gene) >> arrange(X.length, ascending=False) >> head(1))['transcript'].values[0]
		if seq.id == longest_isoform:
			no_isoforms.append(seq)


handle=open(os.path.join(output,sample)+ '.long.fasta', "w")
writer = FastaIO.FastaWriter(handle)
writer.write_file(no_isoforms)
handle.close()
