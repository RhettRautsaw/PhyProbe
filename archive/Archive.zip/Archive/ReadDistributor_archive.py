#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
#import pathos.multiprocessing as mp
import multiprocessing as mp
import random
import pysam
from tqdm import tqdm
import pyfastx
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
	from Bio.SeqIO.QualityIO import FastqGeneralIterator
except:
	print("Error: biopython module is not properly installed.")
	quit()

try:
	import numpy as np
except:
	print("Error: numpy is not properly installed.")
	quit()

try:
	import pandas as pd
except:
	print("Error: pandas is not properly installed.")
	quit()

try:
	from dfply import *
except:
	print("Error: dfply is not properly installed.")
	quit()

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Distribute reads to targets, assemble, and extract consensus.

Assumes targets have the format:
>target_name|genus_species

But delimiter | can be changed with the -d flag.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-r","--reads",
					type=str,
					#default='sample1_R1.fastq.gz,sample1_R2.fastq.gz',
					default='I0796_Daboia_russelii.assembled.fastq',
					help="Comma separated list of reads in fastq(.gz) format (default: %(default)s)")
parser.add_argument("-t","--targets",
					type=str,
					default='../squamate_AHE_UCE_genes_loci2.fasta',
					help="Reference fasta with target loci (default: %(default)s)")
parser.add_argument("-d","--delim",
					type=str,
					default='|',
					help="Delimiter used to separate target/gene names from sample names (default: %(default)s)")
parser.add_argument("-p","--prefix",
					type=str,
					#default='sample1',
					default='I0796_Daboia_russelii',
					help="Unique name of sample for output (default: %(default)s)")
parser.add_argument("-o","--output",
					type=str,
					default="00_distribute",
					help="Folder in which to export results (default: %(default)s)")
parser.add_argument("--percent",
					type=int,
					default=25,
					help="Percent missing data (gaps) allowed in a locus. (default: %(default)s)")
parser.add_argument("--bam",
					action="store_true",
					default=False,
					help="Use mapping with minimap2 instead of blast search")
parser.add_argument("-c","--cpu",
					type=int,
					default=8,
					help="Number of threads to be used in each step. (default: %(default)s)")
args=parser.parse_args()

########################################
################# SETUP ################
########################################

tmp = args.reads.split(",")
reads=[]
for i in tmp:
	reads.append(os.path.abspath(i))

targets_name = os.path.abspath(args.targets)
delim = args.delim
prefix = args.prefix
output = args.output
percent = args.percent/100
bam = args.bam
num_threads = args.cpu

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting ReadDistributor...")
start_dir = os.getcwd()
print("\tReads -> "+ ','.join(tmp))
print("\tTargets -> "+ targets_name)
print("\tPrefix -> "+ prefix)
print("\tOutput -> "+ output)
print("\tPercent -> "+ str(percent))
print("\tThreads -> "+ str(num_threads))
print("\tUsing Mapping -> "+ str(bam))

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

#def CreateDict(ref, read_hit_dict, fa):
def CreateDict(ref):
	print(ref)
	fa = pyfastx.Fasta(prefix2 + ".combined.fasta")
	# DEFINE REFERENCE WORKING DIRECTORIES AND PREFIX
	ref_wd = os.path.join(wd,ref) # output/prefix/ref
	ref_prefix = os.path.join(ref_wd, ref) # output/prefix/ref/ref
	
	# CREATE DIRECTORY FOR EACH REFERENCE, SUBSET ALIGNFILE, DETERMINE BEST REF, 
	mkdir_p(ref_wd)
	sub_blast = alignfile >> mask(X.ref == ref)
	sub_reads = list(sub_blast.qseqid.unique())
	best_ref = list((sub_blast >> arrange(X.score, X.length, ascending=False) >> head(1)).sseqid)
	
	# EXTRACT BEST TARGET SEQ
	for seq in targets:
		if seq.id in best_ref:
			output_handle = open(ref_prefix + '_ref.fasta','a')
			SeqIO.write(seq, output_handle, "fasta")
			output_handle.close()
	
	for read in sub_reads:
		seq=fa[read].seq
		outfile = open(ref_prefix + '_reads.fasta','a')
		outfile.write(">{}\n{}\n".format(read,seq))
		outfile.close()
		
	#with open(ref_prefix + '_reads.list', 'w') as filehandle:
	#	for item in sub_reads:
	#		filehandle.write('%s\n' % item)
	#sp.call("seqtk subseq " + all_reads + " " + ref_prefix + "_reads.list > " + ref_prefix + "_reads.fastq", shell=True)
	
	# CREATE DICTIONARY OF FASTQ READS AS KEYS AND MATCHED LOCI AS VALUES
	#for i in sub_reads:
	#	if i not in read_hit_dict:
	#		read_hit_dict[i] = list()
	#	d = read_hit_dict[i]
	#	d.append(ref)
	#	read_hit_dict[i] = d
	#	#read_hit_dict[i].append(ref)

def FastqParser(rec):
	if rec.id in read_hit_dict:
		t=read_hit_dict[rec.id]
		for i in t:
			output_handle = open(os.path.join(wd,i,"{}_reads.fastq".format(i)),'a')
			SeqIO.write(rec, output_handle, "fasta")
			output_handle.close()

def FastqParser2(rec):
	ID=rec[0].split()[0]
	SEQ=rec[1]
	if ID in read_hit_dict:
		t=read_hit_dict[ID]
		for i in t:
			outfile = open(os.path.join(wd,i,"{}_reads.fasta".format(i)),'a')
			outfile.write(">{}\n{}\n".format(ID,SEQ))
			outfile.close()

def FastaParser(rec):
	if rec.name in read_hit_dict:
		t=read_hit_dict[rec.name]
		for i in t:
			outfile = open(os.path.join(wd,i,"{}_reads.fasta".format(i)),'a')
			outfile.write(">{}\n{}\n".format(rec.name,rec.seq))
			outfile.close()

def FastaParser2(rec):
	t=read_hit_dict[rec]
	seq=fa[rec].seq
	for i in t:
		outfile = open(os.path.join(wd,i,"{}_reads.fasta".format(i)),'a')
		outfile.write(">{}\n{}\n".format(rec,seq))
		outfile.close()

def Assembler(ref, percent):
	# DEFINE REFERENCE WORKING DIRECTORIES AND PREFIX
	ref_wd = os.path.join(wd,ref) # output/prefix/ref
	ref_prefix = os.path.join(ref_wd, ref) # output/prefix/ref/ref
	
	sp.call("spades.py --only-assembler --threads 1 --cov-cutoff 8 -s " + ref_prefix + "_reads.fasta -o " + os.path.join(ref_wd,"spades"), shell=True)
	if os.path.isfile(os.path.join(ref_wd,"spades/contigs.fasta")):
		sp.call("mv " + os.path.join(ref_wd,"spades/contigs.fasta") + " " + ref_prefix + "_contigs.fasta", shell=True)
	else:
		sp.call("seqtk seq -a " + ref_prefix + "_reads.fastq" + " > " + ref_prefix + "_contigs.fasta", shell=True)
	sp.call('minimap2 -ax splice ' + ref_prefix + "_ref.fasta " + ref_prefix + "_contigs.fasta > " + os.path.join(ref_wd,"align.sam"), shell=True)
	sp.call('sam2con.py -i ' + os.path.join(ref_wd,"align.sam") + ' -o ' + ref_wd + ' -p "' + ref + '" -p2 "' + ref + '|' + prefix + '"', shell=True)
	if os.path.isfile(ref_prefix + '_consensus.fasta'):
		tmp_seq = list(SeqIO.parse(ref_prefix + '_consensus.fasta','fasta'))
		for seq in tmp_seq:
			c = seq.seq.count("-")
			l = len(seq.seq)
			if c/l < percent:
				output_handle = open(ref_wd + ".fasta",'a')
				SeqIO.write(seq, output_handle, "fasta")
				output_handle.close()
	
	#	sp.call('rm -r ' + os.path.join(ref_wd), shell=True)
	else:
		sp.call('rm -r ' + os.path.join(ref_wd), shell=True)
	
	sp.call('cat '+ ref_wd + '.fasta >> ' + wd + '.targets.fasta', shell=True)

########################################
################# CODE #################
########################################

wd = os.path.join(output,prefix) # output/prefix
prefix2 = os.path.join(wd,prefix) # output/prefix/prefix
mkdir_p(wd)

targets = list(SeqIO.parse(targets_name,'fasta'))
all_refs = set([seq.id.split(delim)[0] for seq in targets])

all_reads = prefix2 + ".combined.fastq"

# Concatenate reads together
sp.call("rm " + all_reads, shell=True)
for file in reads:
	if '.gz' in file:
		sp.call("zcat " + file + " >> " + all_reads, shell=True)
	else:
		sp.call("cat "  + file + " >> " + all_reads, shell=True)

# Align reads with target file
if bam:
	sp.call("minimap2 -ax sr -t " + str(num_threads) + " " + targets_name + " " + all_reads + " > " + prefix2 + ".sam" , shell=True)
	sp.call("grep -v ^@ " + prefix2 + ".sam > " + prefix2 + ".sam2", shell=True)
	alignfile = pd.read_csv(prefix2 + ".sam2", sep="\t", names=['qseqid', 'flag', 'sseqid', 'pos', 'score', 'cigar', 'rnext', 'pnext', 'length', 'seq', 'qual'])
else:
	#sp.call("seqtk seq -a " + all_reads + " > " + prefix2 + ".combined.fasta", shell=True)
	#sp.call("blastn -query " + prefix2 + ".combined.fasta -db " + targets_name + " -max_target_seqs 10 -evalue 1e-10 -outfmt 6 -num_threads " + str(num_threads) + " > " + prefix2 + ".blast", shell=True)
	alignfile = pd.read_csv(prefix2 + ".blast", sep="\t", names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'score'])

# PARSE BLAST/BAM RESULTS TO IDENTIFY BEST REF AND CREATE DICT
alignfile = alignfile >> mutate(tmp = X.sseqid) >> separate(X.tmp, ['ref'], sep="\\"+delim)
refs = list(alignfile.ref.unique())
print(prefix + ": " + str(len(alignfile)) + " read hits representing " + str(len(refs)) + " of " + str(len(all_refs)) + " targets have hits")

print("distributing best refs and creating dictionary")
p = mp.Pool(num_threads)
#manager = mp.Manager()
#read_hit_dict= manager.dict()
#p.apply_async(CreateDict, [ref, read_hit_dict, fa])

for ref in refs2:
	p.apply_async(CreateDict, [ref])

p.close()
p.join()

print("converting dictionary")
read_hit_dict = dict(read_hit_dict)

#print("creating hits list")
#with open(prefix2 + '_hits.list', 'w') as filehandle:
#	for item in read_hit_dict:
#		filehandle.write('%s\n' % item)

#print("seqtk subseq")
#sp.call("seqtk subseq " + all_reads + " " + prefix2 + "_hits.list > " + prefix2 + "_hits.fastq", shell=True)

# PARSE FASTQ READS INTO APPROPRIATE LOCI
#print("parsing fastq")
#fastq_parser = SeqIO.parse(prefix2 + ".combined.fasta", "fasta")
#fastq_parser = FastqGeneralIterator(open(prefix2 + ".combined.fastq"))
#fa = pyfastx.Fasta(prefix2 + ".combined.fasta")
#p = mp.Pool(num_threads)
#for rec in fastq_parser:
#	p.apply_async(FastqParser2, [rec])
#	FastaParser(rec)
#for rec in read_hit_dict:
#	FastaParser2(rec)

#p.close()
#p.join()

sp.call("rm " + all_reads, shell=True)

# RUN SPADES ASSEMBLY AND SCAFFOLD (REMOVING GAPS).
p = mp.Pool(num_threads)
for ref in refs:
	p.apply_async(Assembler, [ref])

p.close()
p.join()
