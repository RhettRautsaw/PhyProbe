#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
except:
	print("Error: biopython module is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Searches fasta for sample name (or general string) and exports a new fasta. 
Similar to grep, but can handle multi-line fastas.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-n","--name",
					type=str,
					default='sample1',
					help="Name of sample to extract and prefix for new file (default: %(default)s)")
parser.add_argument("-s","--sequences",
					type=str,
					default='sequences.fasta',
					help="Fasta file from which to extract sequences (default: %(default)s)")
parser.add_argument("-o","--output",
					type=str,
					default='.',
					help="Location to export new fasta (default: %(default)s)")
args=parser.parse_args()

########################################
################# CODE #################
########################################

name = args.name
sequences_name = os.path.abspath(args.sequences)
sequences = list(SeqIO.parse(sequences_name,'fasta'))
output = os.path.abspath(args.output)

sample_seqs=[]
for seq in sequences:
	if name in seq.id:
		sample_seqs.append(seq)

handle=open(os.path.join(output,name)+ '.fasta', "w")
writer = FastaIO.FastaWriter(handle)
writer.write_file(sample_seqs)
handle.close()
