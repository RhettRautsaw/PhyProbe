#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
#import pathos.multiprocessing as mp
import multiprocessing as mp
import random
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
except:
	print("Error: biopython module is not properly installed.")
	quit()

try:
	import numpy as np
except:
	print("Error: numpy is not properly installed.")
	quit()

try:
	import pandas as pd
except:
	print("Error: pandas is not properly installed.")
	quit()

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Determine which single copy loci from orthofinder are unique compared to target loci

Assumes targets have the format:
>target_name|genus_species

But delimiter | can be changed with the -d flag.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-q","--query",
					type=str,
					default='protein_coding_targets.tmp.fasta',
					help="Reference fasta with orthofinder single copy loci (default: %(default)s)")
parser.add_argument("-db","--database",
					type=str,
					default='squamate_AHE_UCE_genes_loci2.fasta',
					help="Reference fasta with target loci (default: %(default)s)")
parser.add_argument("-d","--delim",
					type=str,
					default='|',
					help="Delimiter used to separate target/gene names from sample names (default: %(default)s)")
parser.add_argument("-o","--output",
					type=str,
					default='.',
					help="Folder to export results (default: %(default)s)")
parser.add_argument("-c","--cpu",
					type=int,
					default=8,
					help="Number of threads to be used in each step. (default: %(default)s)")
args=parser.parse_args()

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

########################################
################# CODE #################
########################################

query_name = os.path.abspath(args.query)
query_name2=query_name.split("/")[-1]
query_name2=query_name2.split(".")[0]
db_name = os.path.abspath(args.database)
delim=args.delim
output=os.path.abspath(args.output)
num_threads = args.cpu

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting Unique Loci Reduction...")
print("\tQuery Loci -> "+ query_name)
print("\tDatabase Loci -> "+ db_name)
print("\tDelim -> "+ delim)
print("\tOutput -> "+ output)
print("\tThreads -> "+ str(num_threads))

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: Reading in Data...")
cds_targets_tmp = list(SeqIO.parse(query_name,'fasta'))

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: Running BLAST...")
if not os.path.isfile(db_name + ".nin"):
	sp.call('makeblastdb -in ' + db_name + ' -dbtype nucl', shell=True)
sp.call('blastn -query ' + query_name + ' -db ' + db_name + ' -evalue 1e-10 -outfmt 6 -num_threads ' + str(num_threads) + ' > query_to_target.blast', shell=True)

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: Parsing query fasta...")
blastfile = pd.read_csv('query_to_target.blast', sep="\t", names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore'])
blastfile = list(blastfile['qseqid'])
blastfile2 = list(set([x.split(delim)[0] for x in blastfile]))
cds_targets = []
unique_ogs = []
for seq in cds_targets_tmp:
	locus = seq.id.split(delim)[0]
	if locus not in blastfile2:
		cds_targets.append(seq)
		if locus not in unique_ogs:
			unique_ogs.append(locus)

handle=open(os.path.join(output,query_name2) + "_final.fasta", "w")
writer = FastaIO.FastaWriter(handle)
writer.write_file(cds_targets)
handle.close()

print(str(len(unique_ogs)) + " query loci are unique from target loci")
