#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
import pathos.multiprocessing as mp
import random
import pysam
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
	from Bio.SeqIO.QualityIO import FastqGeneralIterator
	from Bio import Phylo
	from Bio import AlignIO
	from Bio.Nexus import Nexus
except:
	print("Error: biopython module is not properly installed.")
	quit()

try:
	import numpy as np
except:
	print("Error: numpy is not properly installed.")
	quit()

try:
	import pandas as pd
except:
	print("Error: pandas is not properly installed.")
	quit()

try:
	from dfply import *
except:
	print("Error: dfply is not properly installed.")
	quit()

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Phylo Ortholog Finder

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-t","--transcriptomes",
					type=str,
					default='Transcriptomes',
					help="Folder of trimmed transcriptome reads in fastq(.gz) format (default: %(default)s) ")
parser.add_argument("-m","--model",
					type=str,
					default='models/VERT_full',
					help="Path to CodAn model for transcriptome CDS prediction (default: %(default)s)")
parser.add_argument("-s","--seqcap",
					type=str,
					default='SeqCap',
					help="Folder of trimmed sequence capture (SeqCap) reads in fastq(.gz) format (default: %(default)s)")
parser.add_argument("--targets",
					#type=argparse.FileType('r+'),
					type=str,
					default='squamate_AHE_UCE_genes_loci2.fasta',
					help="Reference fasta of SeqCap target loci (default: %(default)s)")
parser.add_argument("-o","--other",
					type=str,
					default='Other',
					help="Folder of other data sources to search (default: %(default)s)")
parser.add_argument("-p","--percent",
					type=int,
					default=50,
					help="Percent missing data allowed. (default: %(default)s)")
parser.add_argument("--bam",
					action="store_true",
					default=False,
					help="Use mapping with minimap2 instead of blast search")
parser.add_argument("-c","--cpu",
					type=int,
					default=8,
					help="Number of threads to be used in each step. (default: %(default)s)")
parser.add_argument("--memory",
					type=str,
					default='32G',
					help="Max amount of memory for Trinity assembly (not required unless performing steps 1 or 10). (default: %(default)s)")
parser.add_argument("--steps",
					type=str,
					default='2,3,4,5,5.5,6,7,9,10,11,12,13,14,15',
					help="Comma-separated list of steps in the pipeline to perform. Note that each step requires that files and folder structure be correct. (default: %(default)s)")
parser.add_argument("--version", action='version', version='PhyloOrthogFinder v1')
args=parser.parse_args()

########################################
################# SETUP ################
########################################

transcriptomes = os.path.abspath(args.transcriptomes)
model = os.path.abspath(args.model)
seqcap = os.path.abspath(args.seqcap)
targets_name = os.path.abspath(args.targets)
targets = list(SeqIO.parse(targets_name,'fasta'))
other = os.path.abspath(args.other)
percent = args.percent/100
bam = args.bam
num_threads = args.cpu
max_mem = args.memory
steps = args.steps.split(",")

print("""

PhyProbe

""")

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting PhyProbe...")
start_dir = os.getcwd()
print("\tTranscriptomes -> "+ transcriptomes)
print("\tSeqCap -> "+ seqcap)
print("\Other -> "+ other)
print("\tSeqCap Targets -> "+ targets_name)
print("\tNumber of CPU -> "+ str(num_threads))
print("\tPerforming Steps -> "+ args.steps)
print("\tVersion --> PhyProbe v2\n")

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

def single_or_paired():
	files = glob.glob("*.fastq*")
	sample_dict = set([x.split('.')[0] for x in files])
	#sample_dict = dict(zip(files2,[files2.count(i) for i in files2]))
	return sample_dict

def S1_Trinity(sample, sample_dict, folder):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	reads = glob.glob(sample + '*fastq*')
	wd = os.path.join(folder,sample)
	if len(reads) == 1:
		sp.call('Trinity --seqType fq --CPU ' + str(num_threads) + ' --min_contig_length 200 --max_memory ' + max_mem + ' --full_cleanup --output ' + wd + '.trinity --single ' + reads[0], shell=True)
	if len(reads) == 2:
		sp.call('Trinity --seqType fq --CPU ' + str(num_threads) + ' --min_contig_length 200 --max_memory ' + max_mem + ' --full_cleanup --output ' + wd + '.trinity --left ' + reads[0] + ' --right ' + reads[1], shell=True)
	if len(reads) > 2:
		print("Uncertain if data is paired or single end...cannot complete Trinity assembly")
		print("Please make sure that your fastq files are formatted appropriately")

def S2_CodAn(sample):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	assembly = glob.glob('01_trinity/' + sample)[0]
	sp.call('codan.py -t ' + assembly + ' -m ' + model + ' -o ' + sample + '.tmp -c ' + str(num_threads), shell=True)
	sp.call('mv ' + sample + '.tmp/ORF_sequences.fasta 02_codan/' + sample + '.cds.fasta', shell=True)
	sp.call('rm -r ' + sample + '.tmp', shell=True)

def S3_LongIsoforms(sample):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	sequences = list(SeqIO.parse('02_codan/' + sample + '.cds.fasta','fasta'))
	no_isoforms = []
	genes_list = []
	for seq in sequences:
		gene = seq.id.split('_i')[0]
		if gene not in genes_list:
			genes_list.append(gene)
			matches = []
			matches.append(seq)
			for seq1 in sequences:
				gene1 = seq1.id.split('_i')[0]
				if seq.id != seq1.id and gene == gene1:
					matches.append(seq1)
			if len(matches) > 1:
				lengths = []
				for seq1 in matches:
					lengths.append(len(seq1))
				i = lengths.index(max(lengths))
				no_isoforms.append(matches[i])
			else:
				no_isoforms.append(seq)
	handle=open('03_no_isoforms/' + sample + '.long.fasta', "w")
	writer = FastaIO.FastaWriter(handle)
	writer.write_file(no_isoforms)
	handle.close()

def S4_Cluster(sample):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	sp.call('cd-hit-est -i 03_no_isoforms/' + sample + '.long.fasta -o 04_clustered/' + sample + '.clust.fasta -c 1 -d 0', shell=True)
	sp.call("perl -pi -e 's/>/>" + sample + "|/g' 04_clustered/" + sample + '.clust.fasta', shell=True)

def S5_OrthoSorter(sample_list, folder):
	file = glob.glob(folder + '/Results_*/Orthogroups/Orthogroups.GeneCount.tsv')[0]
	GeneCount = pd.read_csv(file, sep='\t', index_col=0)
	
	# Determine if the max gene count is less than or equal to 1 (single copy genes only)
	GeneCount2 = GeneCount.drop(columns=['Total'])
	GeneCount['sub1'] = list(GeneCount2.max(axis=1) <= 1)
	# Determine if the total gene count has less than X missing data
	#col_count = GeneCount.shape[1]-1
	#per_miss = round(percent * col_count)
	#GeneCount['sub2'] = list(GeneCount.Total >= per_miss)
	# Subset Orthogroups
	GeneCount = GeneCount[GeneCount["sub1"]]
	#GeneCount = GeneCount[GeneCount["sub2"]]
	
	Orthogroups = list(GeneCount.index.values)
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Extracting ' + str(len(Orthogroups)) + ' single-copy orthogroups with <' + str(args.percent) + '% missing data :::')
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Extracting ' + str(len(Orthogroups)) + ' single-copy orthogroups :::')
	
	mkdir_p('05_orthofinder/genes')
	def OG_extract(file):
		file_name = file.split("/")[-1]
		prefix = file_name.split(".fa")[0]
		if prefix in Orthogroups:
			sp.call('cp '+ file + ' 05_orthofinder/genes/' + prefix + '.fasta',shell=True)
			sp.call("perl -pi -e 's/>/>" + prefix + "|/g' 05_orthofinder/genes/" + prefix + '.fasta', shell=True)
			sp.call("perl -pi -e 's/\|TRINITY.*//g' 05_orthofinder/genes/" + prefix + '.fasta', shell=True)
	
	p = mp.Pool(num_threads)
	for f in glob.glob('05_orthofinder/Results_*/Orthogroup_Sequences/*.fa'):
		p.apply_async(OG_extract, [f])
	
	p.close()
	p.join()
	
	sp.call('cat 05_orthofinder/genes/*.fasta > 05_orthofinder/single_copy_genes.fasta', shell=True)
	
	sequences = list(SeqIO.parse('05_orthofinder/single_copy_genes.fasta','fasta'))
	for sample in sample_list:
		sample_seqs = []
		for seq in sequences:
			if sample in seq.id:
				sample_seqs.append(seq)
		handle=open('05_orthofinder/' + sample + '.fasta', "w")
		writer = FastaIO.FastaWriter(handle)
		writer.write_file(sample_seqs)
		handle.close()

def Distribute(sample, targets_name, folder, bam):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	wd = os.path.join(folder,sample)
	mkdir_p(wd)
	reads = glob.glob(sample + '*fastq*')
	targets = list(SeqIO.parse(targets_name,'fasta'))
	all_refs = set([seq.id.split("|")[0] for seq in targets])
	
	# Align reads with target file
	if bam:
		sp.call("minimap2 -ax sr -t " + str(num_threads) + " " + targets_name + " " + ' '.join(reads) + " > " + os.path.join(wd,sample) + ".sam" , shell=True)
		sp.call("grep -v ^@ " + os.path.join(wd,sample) + ".sam > " + os.path.join(wd,sample) + ".sam2", shell=True)
		alignfile = pd.read_csv(os.path.join(wd,sample) + ".sam2", sep="\t", names=['qseqid', 'flag', 'sseqid', 'pos', 'score', 'cigar', 'rnext', 'pnext', 'length', 'seq', 'qual'])
	else:
		sp.call("cat " + " ".join(reads) + " > " + os.path.join(wd,sample) + ".combined.fastq", shell=True)
		sp.call("seqtk seq -a " + os.path.join(wd,sample) + ".combined.fastq | blastn -query - -db " + targets_name + " -max_target_seqs 10 -evalue 1e-10 -outfmt 6 -num_threads " + str(num_threads) + " >> " + os.path.join(wd,sample) + ".blast", shell=True)
		alignfile = pd.read_csv(os.path.join(wd,sample) + ".blast", sep="\t", names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'score'])
	alignfile = alignfile >> mutate(tmp = X.sseqid) >> separate(X.tmp, ['ref'], sep="\|")
	refs = list(alignfile.ref.unique())
	read_hit_dict={}
	print(sample + ": " + str(len(alignfile)) + " read hits representing " + str(len(refs)) + " of " + str(len(all_refs)) + " targets have hits")
	for ref in refs:
		# CREATE DIRECTORY FOR EACH REFERENCE, SUBSET BLAST, DETERMINE BEST REF, 
		mkdir_p(os.path.join(wd,ref))
		sub_blast = alignfile >> mask(X.ref == ref)
		sub_reads = list(sub_blast.qseqid.unique())
		best_ref = list((sub_blast >> arrange(X.score, X.length, ascending=False) >> head(1)).sseqid)
		
		# EXTRACT BEST TARGET SEQ
		for seq in targets:
			if seq.id in best_ref:
				output_handle = open(os.path.join(wd,ref,"{}_ref.fasta".format(ref)),'a')
				SeqIO.write(seq, output_handle, "fasta")
				output_handle.close()
		
		# CREATE DICTIONARY OF FASTQ READS AS KEYS AND MATCHED LOCI AS VALUES
		for i in sub_reads:
			if i not in read_hit_dict:
				read_hit_dict[i] = list()
			read_hit_dict[i].append(ref)
	
	# PARSE FASTQ READS INTO APPROPRIATE LOCI
	fastq_parser = SeqIO.parse(os.path.join(wd,sample) + ".combined.fastq", "fastq")
	for rec in fastq_parser:
		if rec.id in read_hit_dict:
			t=read_hit_dict[rec.id]
			for i in t:
				output_handle = open(os.path.join(wd,i,"{}_reads.fastq".format(i)),'a')
				SeqIO.write(rec, output_handle, "fastq")
				output_handle.close()
	
	sp.call("rm " + os.path.join(wd,sample) + ".combined.fastq", shell=True)
	
	# RUN SPADES ASSEMBLY AND SCAFFOLD (REMOVING GAPS)...KEEP ALTERNATE MAPS AS PARALOGS
	for ref in refs:
		sp.call("spades.py --only-assembler --threads " + str(num_threads) + " --cov-cutoff 8 -s " + os.path.join(wd,ref,"{}_reads.fastq".format(ref)) + " -o " + os.path.join(wd,ref,"spades"), shell=True)
		if os.path.isfile(os.path.join(wd,ref,"spades/contigs.fasta")):
			sp.call("mv " + os.path.join(wd,ref,"spades/contigs.fasta") + " " + os.path.join(wd,ref,"{}_contigs.fasta".format(ref)), shell=True)
		else:
			sp.call("seqtk seq -a " + os.path.join(wd,ref,"{}_reads.fastq".format(ref)) + " > " + os.path.join(wd,ref,"{}_contigs.fasta".format(ref)), shell=True)
		sp.call("rm -r " + os.path.join(wd,ref,"spades"), shell=True)
		sp.call('minimap2 -ax splice ' + os.path.join(wd,ref,"{}_ref.fasta".format(ref)) + " " + os.path.join(wd,ref,"{}_contigs.fasta".format(ref)) + ' > ' + os.path.join(wd,ref,"align.sam"), shell=True)
		sp.call('sam2con.py -i ' + os.path.join(wd,ref,"align.sam") + ' -o ' + os.path.join(wd,ref) + ' -p "' + ref + '" -p2 "' + ref + '|' + sample + '"', shell=True)
		if os.path.isfile(os.path.join(wd,ref,ref) + '_consensus.fasta'):
			tmp_seq = list(SeqIO.parse(os.path.join(wd,ref,ref) + '_consensus.fasta','fasta'))
			for seq in tmp_seq:
				c = seq.seq.count("-")
				l = len(seq.seq)
				if c/l < 0.25:
					output_handle = open(os.path.join(wd,"{}.fasta".format(ref)),'a')
					SeqIO.write(seq, output_handle, "fasta")
					output_handle.close()
			sp.call('rm -r ' + os.path.join(wd,ref), shell=True)
		else:
			sp.call('rm -r ' + os.path.join(wd,ref), shell=True)
		
		sp.call('cat '+ os.path.join(wd,ref) + '.fasta >>' + os.path.join(folder,sample) + '.targets.fasta', shell=True)

def Unambigufy(seq):
	d = {'A': 'A',
		'C': 'C',
		'G': 'G',
		'T': 'T',
		'M': 'AC',
		'R': 'AG',
		'W': 'AT',
		'S': 'CG',
		'Y': 'CT',
		'K': 'GT',
		'V': 'ACG',
		'H': 'ACT',
		'D': 'AGT',
		'B': 'CGT',
		'-': 'N',
		'N': 'N'}
	
	seq2=''
	for letter in seq:
		choice=random.choice(d.get(letter))
		seq2= seq2 + choice
	return seq2

def Phasing(sample, targets_name, folder):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	mkdir_p(folder)
	wd=os.path.join(folder,sample)
	ref = list(SeqIO.parse(targets_name,'fasta'))
	new_ref = []
	for rec in ref:
		r = rec
		seq = str(r.seq).upper()
		new_seq = Unambigufy(seq)
		r.seq = Seq(new_seq)
		new_ref.append(r)
	
	handle=open(wd + '.tmp.fasta', "w")
	writer = FastaIO.FastaWriter(handle)
	writer.write_file(new_ref)
	handle.close()

	sp.call('minimap2 -ax sr ' + wd + '.tmp.fasta ' + sample + '*.fastq.gz | samtools sort > ' + wd + '.tmp.bam', shell=True)
	sp.call('samtools index ' + wd + '.tmp.bam', shell=True)
	sp.call('bcftools mpileup -I -f ' + wd + '.tmp.fasta ' + wd + '.tmp.bam | bcftools call -mv -V indels -Oz > ' + wd + '.tmp.vcf.gz', shell=True)
	sp.call('bcftools index ' + wd + '.tmp.vcf.gz', shell=True)
	sp.call('whatshap phase --ignore-read-groups --reference=' + wd + '.tmp.fasta -o ' + wd + '.tmp.phased.vcf ' + wd + '.tmp.vcf.gz ' + wd + '.tmp.bam', shell=True)
	sp.call('bcftools norm -f ' + wd + '.tmp.fasta -m +any -Oz -o ' + wd + '.tmp.phased.norm.vcf.gz ' + wd + '.tmp.phased.vcf', shell=True)
	sp.call('tabix ' + wd + '.tmp.phased.norm.vcf.gz', shell=True)
	sp.call('bcftools consensus -H 1 -f ' + wd + '.tmp.fasta ' + wd + '.tmp.phased.norm.vcf.gz > ' + wd + '.tmp.hap0.fasta', shell=True)
	sp.call('bcftools consensus -H 2 -f ' + wd + '.tmp.fasta ' + wd + '.tmp.phased.norm.vcf.gz > ' + wd + '.tmp.hap1.fasta', shell=True)
	combined_haps = []
	hap0 = list(SeqIO.parse(wd + '.tmp.hap0.fasta','fasta'))
	hap1 = list(SeqIO.parse(wd + '.tmp.hap1.fasta','fasta'))
	for seq in hap0:
		seq.id = seq.name = seq.description = seq.id + "|h0"
		seq.seq = seq.seq.ungap("N")
		combined_haps.append(seq)
	
	for seq in hap1:
		seq.id = seq.name = seq.description = seq.id + "|h1"
		seq.seq = seq.seq.ungap("N")
		combined_haps.append(seq)
	
	sp.call('rm ' + wd + '.tmp.*', shell=True)
	
	handle=open(wd + '.haplotypes.fasta', "w")
	writer = FastaIO.FastaWriter(handle)
	writer.write_file(combined_haps)
	handle.close()


########################################
############ TRANSCRIPTOMES ############
########################################

if os.path.isdir(transcriptomes): 
	os.chdir(transcriptomes)
	
	rna_samp_dict = glob.glob("*.fastq*")
	rna_samp_dict = set([x.split('.')[0] for x in rna_samples])
	
	## STEP 1 : RUNNING TRINITY
	
	if '1' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 1 ::: Running Trinity Transcriptome Samples :::'
		print(string)
		print('=' * len(string))
		mkdir_p('01_trinity')
		for sample in rna_samp_dict:
			S1_Trinity(sample, rna_samp_dict, '01_trinity')
	
	## STEP 2 : RUNNING CODAN
	
	if '2' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 2 ::: Running CodAn on Trinity Assemblies :::'
		print(string)
		print('=' * len(string))
		mkdir_p('02_codan')
		for sample in rna_samp_dict:
			S2_CodAn(sample)
	
	## STEP 3 : REMOVING SHORT ISOFORMS
	
	if '3' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 3 ::: Getting longest isoforms :::'
		print(string)
		print('=' * len(string))
		mkdir_p('03_no_isoforms')
		p = mp.Pool(num_threads)
		for sample in rna_samp_dict:
			p.apply_async(S3_LongIsoforms, [sample])
		
		p.close()
		p.join()
	
	## STEP 4 : CLUSTERING FURTHER REDUNDANCY
	
	if '4' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 4 ::: Clustering sequences at 100% identity :::'
		print(string)
		print('=' * len(string))
		mkdir_p('04_clustered')
		p = mp.Pool(num_threads)
		for sample in rna_samp_dict:
			p.apply_async(S4_Cluster, [sample])
		
		p.close()
		p.join()
	
	## STEP 5 : RUNNING ORTHOFINDER
	
	if '5' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 5 ::: Running OrthoFinder :::'
		print(string)
		print('=' * len(string))
		
		sp.call('orthofinder -f 04_clustered -d -og -o 05_orthofinder -t ' + str(num_threads), shell=True)
	
	if '5.5' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 5.5 ::: Sorting OrthoFinder Results :::'
		print(string)
		print('=' * len(string))
		S5_OrthoSorter(rna_samp_dict)
	
	## STEP 6 : EXTRACTING TARGET LOCI FROM TRANSCRIPTOMES
	
	if '6' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 6 ::: Extracting Target Loci from Transcriptome Reads :::'
		print(string)
		print('=' * len(string))
		if not os.path.isfile(targets_name + ".nin"):
			sp.call('makeblastdb -in ' + targets_name + ' -dbtype nucl', shell=True)
		
		p = mp.Pool(num_threads)
		for sample in rna_samp_dict:
			p.apply_async(Distribute, [sample, targets_name,'01_trinity', '06_targets'])
		
		p.close()
		p.join()
	
	## STEP 7 : COMBINING AND PHASING
	
	if '7' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 7 ::: Phasing Consensus Sequences :::'
		print(string)
		print('=' * len(string))
		mkdir_p('07_phasing')
		
		p = mp.Pool(num_threads)
		for sample in rna_samp_dict:
			sp.call('cat 05_orthofinder/' + sample + '.fasta 06_targets/' + sample + '.targets.fasta > 07_phasing/' + sample + '.fasta', shell=True)
			tmp_targets = '07_phasing/' + sample + '.fasta'
			p.apply_async(Phasing, [sample, tmp_targets, '07_phasing'])
		
		p.close()
		p.join()
else:
	cds_targets = cds_targets_name = None
	rna_samp_dict = None

########################################
### COMBINE OGs TARGETS WITH TARGETS ###
########################################

if os.path.isfile('05_orthofinder/single_copy_genes.fasta'):
		cds_targets_name = os.path.abspath('05_orthofinder/single_copy_genes.fasta')
		cds_targets_tmp = list(SeqIO.parse(cds_targets_name,'fasta'))
		
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Removing Orthogroups Matching a Target Locus :::'
		print(string)
		print('=' * len(string))
		if not os.path.isfile(targets_name + ".nin"):
			sp.call('makeblastdb -in ' + targets_name + ' -dbtype nucl', shell=True)
		sp.call('blastn -query ' + cds_targets_name + ' -db ' + targets_name + ' -evalue 1e-10 -outfmt 6 -num_threads ' + str(num_threads) + ' > orthogroup_to_target.blast')
		blastfile = pd.read_csv('orthogroup_to_target.blast', sep="\t", names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore'])
		blastfile = list(blastfile['qseqid'])
		cds_targets = []
		unique_ogs = []
		for seq in cds_targets_tmp:
			if seq.id not in blastfile:
				cds_targets.append(seq)
				unique_ogs.append(seq.id.split("|")[0])
		
		handle=open(start_dir + "/prot_coding_targets.fasta", "w")
		writer = FastaIO.FastaWriter(handle)
		writer.write_file(cds_targets)
		handle.close()
		
		print(str(len(unique_ogs)) + " orthogroups are unique from target loci")

combined_targets = []
if targets is not None:
	for seq in targets:
		combined_targets.append(seq)
if cds_targets is not None:
	for seq in cds_targets:
		combined_targets.append(seq)

print(str(len(combined_targets)) + " targets in total ")

combined_targets_name = start_dir + "/combined_targets.fasta"

handle=open(combined_targets_name, "w")
writer = FastaIO.FastaWriter(handle)
writer.write_file(combined_targets)
handle.close()

########################################
########### SEQUENCE CAPTURE ###########
########################################

os.chdir(start_dir)
if os.path.isdir(seqcap): 
	os.chdir(seqcap)
	
	seqcap_samp_dict = single_or_paired()
	
	## STEP 8 : EXTRACTING TARGETS FROM SEQCAP DATA
	
	if '8' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 8 ::: Extracting All Targets from SeqCap Reads :::'
		print(string)
		print('=' * len(string))
		mkdir_p('08_targets')
		if not os.path.isfile(combined_targets_name + ".nin"):
			sp.call('makeblastdb -in ' + combined_targets_name + ' -dbtype nucl', shell=True)
		
		p = mp.Pool(num_threads)
		for sample in seqcap_samp_dict:
			p.apply_async(Distribute, [sample, combined_targets_name, '08_targets', bam])
		
		p.close()
		p.join()
	
	## STEP 9 : COMBINING AND PHASING
	
	if '9' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 9 ::: Phasing Consensus Sequences :::'
		print(string)
		print('=' * len(string))
		mkdir_p('09_phasing')
		p = mp.Pool(num_threads)
		for sample in seqcap_samp_dict:
			tmp_targets = '08_targets/' + sample + '.targets.fasta'
			p.apply_async(Phasing, [sample, tmp_targets, '09_phasing'])
		
		p.close()
		p.join()
else:
	seqcap_samp_dict = None

########################################
############## OTHER DATA ##############
########################################

os.chdir(start_dir)
if os.path.isdir(other): 
	os.chdir(other)
	
	other_samp_dict = single_or_paired()
	
	## STEP 10 : EXTRACTING TARGETS FROM OTHER DATA
	
	if '10' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 10 ::: Extracting All Targets from Other Samples :::'
		print(string)
		print('=' * len(string))
		if not os.path.isfile(combined_targets_name + ".nin"):
			sp.call('makeblastdb -in ' + combined_targets_name + ' -dbtype nucl', shell=True)
		
		p = mp.Pool(num_threads)
		for sample in other_samp_dict:
			p.apply_async(Distribute, [sample, combined_targets_name, '10_targets', bam])
		
		p.close()
		p.join()
	
	## STEP 11 : COMBINING AND PHASING
	
	if '11' in steps:
		string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 11 ::: Phasing Consensus Sequences :::'
		print(string)
		print('=' * len(string))
		mkdir_p('11_phasing')
		p = mp.Pool(num_threads)
		for sample in other_samp_dict:
			tmp_targets = '10_targets/' + sample + '.targets.fasta'
			p.apply_async(Phasing, [sample, tmp_targets, '11_phasing'])
		
		p.close()
		p.join()

########################################
############### COMBINE ################
########################################

os.chdir(start_dir)

if '15' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 15 ::: Consolidate Loci Across Datasets :::'
	print(string)
	print('=' * len(string))
	mkdir_p('12_combined')
	full_sample_list = []
	full_locus_list = []
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: concat transcriptomes :::')
	if rna_samp_dict is not None:
		for sample in rna_samp_dict:
			full_sample_list.append(sample)
			sp.call('cat Transcriptomes/07_phasing/' + sample + '.haplotypes.fasta >> 12_combined/all_loci.fasta', shell=True)
	
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: concat seqcap :::')
	if seqcap_samp_dict is not None:
		for sample in seqcap_samp_dict:
			full_sample_list.append(sample)
			sp.call('cat SeqCap/09_phasing/' + sample + '.haplotypes.fasta >> 12_combined/all_loci.fasta', shell=True)
	
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: concat other :::')
	if other_samp_dict is not None:
		for sample in other_samp_dict:
			full_sample_list.append(sample)
			sp.call('cat Other/11_phasing/' + sample + '.haplotypes.fasta >> 12_combined/all_loci.fasta', shell=True)
	
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: parse loci :::')
	all_loci = list(SeqIO.parse('12_combined/all_loci.fasta','fasta'))
	for rec in all_loci:
		tmp_rec = []
		locus = rec.id.split('|')[0]
		sample = rec.id.split('|')[1:]
		sample = '|'.join(sample)
		rec.id = rec.description = rec.name = sample
		if locus not in full_locus_list:
			full_locus_list.append(locus)
		tmp_rec.append(rec)
		wd = os.path.join('12_combined',locus)
		mkdir_p(wd)
		handle=open(wd + '/' + locus + '.fasta', "a")
		writer = FastaIO.FastaWriter(handle, wrap=None)
		writer.write_file(tmp_rec)
		handle.close()
	
	for rec in targets:
		tmp_rec = []
		locus = rec.id.split('|')[0]
		sample = rec.id.split('|')[1:]
		sample = '|'.join(sample)
		rec.id = rec.description = rec.name = sample
		if locus in full_locus_list:
			tmp_rec.append(rec)
			wd = os.path.join('12_combined',locus)
			mkdir_p(wd)
			handle=open(wd + '/' + locus + '.fasta', "a")
			writer = FastaIO.FastaWriter(handle, wrap=None)
			writer.write_file(tmp_rec)
			handle.close()


#parallel -a loci.list -j 8 'echo {}
#	mkdir {}
#	mv {}.fasta {}
#	cd {}
#	mafft --auto {}.fasta > {}.aln
#	trimal -in {}.aln -out {}.aln.trimmed -automated1
#	iqtree -s {}.aln.trimmed -bb 1000 -seed 12345'
#
#for i in `cat loci.list`
#	do echo $i
#	cat $i/$i.aln.trimmed.contree >> gene_trees.newick
#	done
#
#java -jar ~/Dropbox/bin/Astral/astral.5.6.3.jar

