#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
import pathos.multiprocessing as mp
import random
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
	from Bio.SeqIO.QualityIO import FastqGeneralIterator
	from Bio import Phylo
	from Bio import AlignIO
	from Bio.Nexus import Nexus
except:
	print("Error: biopython module is not properly installed.")
	quit()

try:
	import numpy as np
except:
	print("Error: numpy is not properly installed.")
	quit()

try:
	import pandas as pd
except:
	print("Error: pandas is not properly installed.")
	quit()

try:
	from dfply import *
except:
	print("Error: dfply is not properly installed.")
	quit()

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Phylo Ortholog Finder

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-t","--transcriptomes",
					type=str,
					default='Transcriptomes',
					help="Folder of trimmed transcriptome reads in fastq(.gz) format (default: %(default)s) ")
parser.add_argument("-m","--model",
					type=str,
					default='models/VERT_full',
					help="Path to CodAn model for transcriptome CDS prediction (default: %(default)s)")
parser.add_argument("-s","--seqcap",
					type=str,
					default='SeqCap',
					help="Folder of trimmed sequence capture (SeqCap) reads in fastq(.gz) format (default: %(default)s)")
parser.add_argument("-r","--targets",
					#type=argparse.FileType('r+'),
					type=str,
					default='squamate_AHE_UCE_genes_loci2.fasta',
					help="Reference fasta of SeqCap target loci (default: %(default)s)")
parser.add_argument("-a","--assemblies",
					type=str,
					default='Other',
					help="Folder of other assemblies to search (default: %(default)s)")
parser.add_argument("-p","--percent",
					type=int,
					default=50,
					help="Percent missing data allowed. (default: %(default)s)")
parser.add_argument("-c","--cpu",
					type=int,
					default=8,
					help="Number of threads to be used in each step. (default: %(default)s)")
parser.add_argument("--memory",
					type=str,
					default='32G',
					help="Max amount of memory for Trinity assembly (not required unless performing steps 1 or 10). (default: %(default)s)")
parser.add_argument("--steps",
					type=str,
					default='2,3,4,5,5.5,6,7,9,10,11,12,13,14,15',
					help="Comma-separated list of steps in the pipeline to perform. Note that each step requires that files and folder structure be correct. (default: %(default)s)")
parser.add_argument("--version", action='version', version='PhyloOrthogFinder v1')
args=parser.parse_args()

########################################
################# SETUP ################
########################################

transcriptomes = os.path.abspath(args.transcriptomes)
model = os.path.abspath(args.model)
seqcap = os.path.abspath(args.seqcap)
targets_name = os.path.abspath(args.targets)
targets = list(SeqIO.parse(targets_name,'fasta'))
assemblies = os.path.abspath(args.assemblies)
percent = args.percent/100
num_threads = args.cpu
max_mem = args.memory
steps = args.steps.split(",")

print("""

PhyProbe

""")

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting PhyProbe...")
start_dir = os.getcwd()
print("\tTranscriptomes -> "+ transcriptomes)
print("\tSeqCap -> "+ seqcap)
print("\Other -> "+ assemblies)
print("\tSeqCap Targets -> "+ targets_name)
print("\tNumber of CPU -> "+ str(num_threads))
print("\tPerforming Steps -> "+ args.steps)
print("\tVersion --> PhyProbe v1\n")

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

def single_or_paired():
	files = glob.glob("*.fastq*")
	files2 = [x.split('.')[0] for x in files]
	sample_dict = dict(zip(files2,[files2.count(i) for i in files2]))
	return sample_dict

def S1_Trinity(sample, sample_dict, folder):
	mkdir_p(folder)
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	if sample_dict[sample] == 1:
		sp.call('Trinity --seqType fq --CPU ' + str(num_threads) + ' --min_contig_length 200 --max_memory ' + max_mem + ' --full_cleanup --output ' + folder + '/' + sample + '.trinity --single ' + sample + '*.fastq*', shell=True)
	if sample_dict[sample] == 2:
		sp.call('Trinity --seqType fq --CPU ' + str(num_threads) + ' --min_contig_length 200 --max_memory ' + max_mem + ' --full_cleanup --output ' + folder + '/' + sample + '.trinity --left ' + sample + '*R1*.fastq* --right ' + sample + '*R2*.fastq*', shell=True)
	if sample_dict[sample] > 2:
		print("Uncertain if data is paired or single end...cannot complete Trinity assembly")
		print("Please make sure that your fastq files are formatted appropriately")

def S2_CodAn(sample):
	mkdir_p('02_codan')
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	sp.call('codan.py -t 01_trinity/' + sample + '*.fasta -m ' + model + ' -o ' + sample + '.tmp -c ' + str(num_threads), shell=True)
	sp.call('mv ' + sample + '.tmp/ORF_sequences.fasta 02_codan/' + sample + '.fasta', shell=True)
	sp.call('rm -r ' + sample + '.tmp', shell=True)

def S3_LongIsoforms(sample):
	mkdir_p('03_no_isoforms')
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	sequences = list(SeqIO.parse('02_codan/' + sample + '.fasta','fasta'))
	no_isoforms = []
	genes_list = []
	for seq in sequences:
		gene = seq.id.split('_i')[0]
		if gene not in genes_list:
			genes_list.append(gene)
			matches = []
			matches.append(seq)
			for seq1 in sequences:
				gene1 = seq1.id.split('_i')[0]
				if seq.id != seq1.id and gene == gene1:
					matches.append(seq1)
			if len(matches) > 1:
				lengths = []
				for seq1 in matches:
					lengths.append(len(seq1))
				i = lengths.index(max(lengths))
				no_isoforms.append(matches[i])
			else:
				no_isoforms.append(seq)
	handle=open('03_no_isoforms/' + sample + '.fasta', "w")
	writer = FastaIO.FastaWriter(handle)
	writer.write_file(no_isoforms)
	handle.close()

def S4_Cluster(sample):
	mkdir_p('04_clustered')
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	sp.call('cd-hit-est -i 03_no_isoforms/' + sample + '.fasta -o 04_clustered/' + sample + '.fasta -c 1 -d 0', shell=True)
	sp.call("perl -pi -e 's/>/>" + sample + "|/g' 04_clustered/" + sample + '.fasta', shell=True)

def S5_OrthoSorter(sample_dict):
	file = glob.glob('05_orthofinder/Results_*/Orthogroups/Orthogroups.GeneCount.tsv')[0]
	GeneCount = pd.read_csv(file, sep='\t', index_col=0)
	
	# Determine if the max gene count is less than or equal to 1 (single copy genes only)
	GeneCount2 = GeneCount.drop(columns=['Total'])
	GeneCount['sub1'] = list(GeneCount2.max(axis=1) <= 1)
	# Determine if the total gene count has less than X missing data
	#col_count = GeneCount.shape[1]-1
	#per_miss = round(percent * col_count)
	#GeneCount['sub2'] = list(GeneCount.Total >= per_miss)
	# Subset Orthogroups
	GeneCount = GeneCount[GeneCount["sub1"]]
	#GeneCount = GeneCount[GeneCount["sub2"]]
	
	Orthogroups = list(GeneCount.index.values)
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Extracting ' + str(len(Orthogroups)) + ' single-copy orthogroups with <' + str(args.percent) + '% missing data :::')
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Extracting ' + str(len(Orthogroups)) + ' single-copy orthogroups :::')
	
	mkdir_p('05_orthofinder/genes')
	def OG_extract(file):
		file_name = file.split("/")[-1]
		prefix = file_name.split(".fa")[0]
		if prefix in Orthogroups:
			sp.call('cp '+ file + ' 05_orthofinder/genes/' + prefix + '.fasta',shell=True)
			sp.call("perl -pi -e 's/>/>" + prefix + "|/g' 05_orthofinder/genes/" + prefix + '.fasta', shell=True)
			sp.call("perl -pi -e 's/\|TRINITY.*//g' 05_orthofinder/genes/" + prefix + '.fasta', shell=True)
	
	p = mp.Pool(num_threads)
	for f in glob.glob('05_orthofinder/Results_*/Orthogroup_Sequences/*.fa'):
		p.apply_async(OG_extract, [f])
	
	p.close()
	p.join()
	
	sp.call('cat 05_orthofinder/genes/*.fasta > 05_orthofinder/single_copy_genes.fasta', shell=True)
	
	sequences = list(SeqIO.parse('05_orthofinder/single_copy_genes.fasta','fasta'))
	for sample in sample_dict:
		sample_seqs = []
		for seq in sequences:
			if sample in seq.id:
				sample_seqs.append(seq)
		handle=open('05_orthofinder/' + sample + '.fasta', "w")
		writer = FastaIO.FastaWriter(handle)
		writer.write_file(sample_seqs)
		handle.close()

## Here we are keeping the full contig
def DistributeContigs(sample, targets_name, assembly_folder, folder):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	file = glob.glob(assembly_folder + '/' + sample + '*.fasta')[0]
	mkdir_p(folder)
	mkdir_p(folder + '/blast_results')
	sequences = list(SeqIO.parse(file,'fasta'))
	targets = list(SeqIO.parse(targets_name,'fasta'))
	
	sp.call("blastn -query " + file + " -db " + targets_name + " -max_target_seqs 10 -evalue 1e-10 -outfmt 6 -num_threads " + str(num_threads) + " -out " + folder + "/blast_results/" + sample + ".tsv", shell=True)
	blastfile = pd.read_csv(folder + '/blast_results/' + sample + '.tsv', sep="\t", names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore'])
	blastfile = blastfile >> mutate(tmp = X.sseqid) >> separate(X.tmp, ['ref'], sep="\|")
	refs = list(blastfile.ref.unique())
	workdir = os.path.join(folder,sample)
	for ref in refs:
		mkdir_p(os.path.join(workdir,ref))
		sub_blast = blastfile >> mask(X.ref == ref)
		contigs = list(sub_blast.qseqid.unique())
		best_ref = list((sub_blast >> arrange(X.bitscore, X.length, X.pident, ascending=False) >> head(1)).sseqid)
		for seq in sequences:
			if seq.id in contigs:
				output_handle = open(os.path.join(workdir,ref,"{}.fasta".format(ref)),'a')
				SeqIO.write(seq, output_handle, "fasta")
				output_handle.close()
		
		for seq in targets:
			if seq.id in best_ref:
				output_handle = open(os.path.join(workdir,ref,"{}_ref.fasta".format(ref)),'a')
				SeqIO.write(seq, output_handle, "fasta")
				output_handle.close()
		
		workdir2 = os.path.join(workdir,ref)
		workdir3 = os.path.join(workdir2,ref)
		sp.call('minimap2 -ax splice ' + workdir3 + '_ref.fasta ' + workdir3 +'.fasta > ' + workdir2 + '/align.sam', shell=True)
		sp.call('sam2con.py -i ' + workdir2 + '/align.sam -o ' + workdir2 + ' -p "' + ref + '" -p2 "' + ref + '|' + sample + '"', shell=True)
		if os.path.isfile(workdir3 + '_consensus.fasta'):
			tmp_seq = list(SeqIO.parse(workdir3 + '_consensus.fasta','fasta'))
			for seq in tmp_seq:
				c = seq.seq.count("-")
				l = len(seq.seq)
				if c/l < 0.25:
					output_handle = open(os.path.join(workdir,"{}.fasta".format(ref)),'a')
					SeqIO.write(seq, output_handle, "fasta")
					output_handle.close()
			sp.call('rm -r ' + os.path.join(workdir,ref), shell=True)
		else:
			sp.call('rm -r ' + os.path.join(workdir,ref), shell=True)
		
		sp.call('cat '+ workdir2 + '.fasta >>' + workdir + '.targets.fasta', shell=True)
	
	#sp.call('cat ' + workdir + '/*.fasta > ' + folder + '/' + sample + '.targets.fasta', shell=True)
	sp.call('rm -r ' + workdir, shell=True)

### Here we only are keeping where the BLAST matches align
#def DistributeContigs2(sample, targets_name, assembly_folder, folder):
#	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
#	file = glob.glob(assembly_folder + '/' + sample + '*.fasta')[0]
#	mkdir_p(folder)
#	mkdir_p(folder + '/blast_results')
#	targets = list(SeqIO.parse(targets_name,'fasta'))
#	
#	sp.call("blastn -query " + file + " -db " + targets_name + " -evalue 1e-10 -outfmt '6 qseqid sseqid qseq sseq pident length mismatch gapopen qstart qend sstart send evalue bitscore' -num_threads " + str(num_threads) + " -out " + folder + "/blast_results/" + sample + ".tsv", shell=True)
#	blastfile = pd.read_csv(folder + '/blast_results/' + sample + '.tsv', sep="\t", names=['qseqid', 'sseqid', 'qseq', 'sseq', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore'])
#	blastfile = blastfile >> mutate(tmp = X.sseqid) >> separate(X.tmp, ['ref'], sep="\|")
#	refs = list(blastfile.ref.unique())
#	workdir = os.path.join(folder,sample)
#	for ref in refs:
#		mkdir_p(os.path.join(workdir,ref))
#		sub_blast = blastfile >> mask(X.ref == ref)
#		contigs = list(sub_blast.qseq.unique())
#		best_ref = list((sub_blast >> arrange(X.bitscore, X.length, X.pident, ascending=False) >> head(1)).sseqid)
#		i=0
#		for seq in contigs:
#			i+=1
#			seq = Seq(seq) #, SingleLetterAlphabet())
#			seq = SeqRecord(seq, "match_"+str(i), '', '')
#			seq.seq = seq.seq.ungap("-")
#			output_handle = open(os.path.join(workdir,ref,"{}.fasta".format(ref)),'a')
#			SeqIO.write(seq, output_handle, "fasta")
#			output_handle.close()
#		
#		for seq in targets:
#			if seq.id in best_ref:
#				output_handle = open(os.path.join(workdir,ref,"{}_ref.fasta".format(ref)),'a')
#				SeqIO.write(seq, output_handle, "fasta")
#				output_handle.close()
#		
#		workdir2 = os.path.join(workdir,ref)
#		workdir3 = os.path.join(workdir2,ref)
#		sp.call('minimap2 -ax splice ' + workdir3 + '_ref.fasta ' + workdir3 +'.fasta > ' + workdir2 + '/align.sam', shell=True)
#		sp.call('sam2con.py -i ' + workdir2 + '/align.sam -o ' + workdir2 + ' -p "' + ref + '" -p2 "' + ref + '|' + sample + '"', shell=True)
#		if os.path.isfile(workdir3 + '_consensus.fasta'):
#			tmp_seq = list(SeqIO.parse(workdir3 + '_consensus.fasta','fasta'))
#			for seq in tmp_seq:
#				c = seq.seq.count("-")
#				l = len(seq.seq)
#				if c/l < 0.25:
#					output_handle = open(os.path.join(workdir,"{}.fasta".format(ref)),'a')
#					SeqIO.write(seq, output_handle, "fasta")
#					output_handle.close()
#			sp.call('rm -r ' + os.path.join(workdir,ref), shell=True)
#		else:
#			sp.call('rm -r ' + os.path.join(workdir,ref), shell=True)
#		
#		sp.call('cat '+ workdir2 + '.fasta >>' + workdir + '.targets.fasta', shell=True)
#	
#	sp.call('rm -r ' + workdir, shell=True)

# Here we use the file of interest as the database and query the targets...keep only what matches (no introns)
def DistributeContigs3(sample, targets_name, assembly_folder, folder):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	file = glob.glob(assembly_folder + '/' + sample + '*.fasta')[0]
	mkdir_p(folder)
	mkdir_p(folder + '/blast_results')
	targets = list(SeqIO.parse(targets_name,'fasta'))
	
	sp.call('makeblastdb -in ' + file + ' -dbtype nucl', shell=True)
	
	sp.call("blastn -query " + targets_name + " -db " + file + " -evalue 1e-10 -outfmt '6 qseqid sseqid qseq sseq pident length mismatch gapopen qstart qend sstart send evalue bitscore' -num_threads " + str(num_threads) + " -out " + folder + "/blast_results/" + sample + ".tsv", shell=True)
	blastfile = pd.read_csv(folder + '/blast_results/' + sample + '.tsv', sep="\t", names=['qseqid', 'sseqid', 'qseq', 'sseq', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore'])
	blastfile = blastfile >> mutate(tmp = X.qseqid) >> separate(X.tmp, ['ref'], sep="\|")
	refs = list(blastfile.ref.unique())
	workdir = os.path.join(folder,sample)
	for ref in refs:
		mkdir_p(os.path.join(workdir,ref))
		sub_blast = blastfile >> mask(X.ref == ref)
		contigs = list(sub_blast.sseq.unique())
		best_ref = list((sub_blast >> arrange(X.bitscore, X.length, X.pident, ascending=False) >> head(1)).qseqid)
		i=0
		for seq in contigs:
			i+=1
			seq = Seq(seq) #, SingleLetterAlphabet())
			seq = SeqRecord(seq, "match_"+str(i), '', '')
			seq.seq = seq.seq.ungap("-")
			output_handle = open(os.path.join(workdir,ref,"{}.fasta".format(ref)),'a')
			SeqIO.write(seq, output_handle, "fasta")
			output_handle.close()
		
		for seq in targets:
			if seq.id in best_ref:
				output_handle = open(os.path.join(workdir,ref,"{}_ref.fasta".format(ref)),'a')
				SeqIO.write(seq, output_handle, "fasta")
				output_handle.close()
		
		workdir2 = os.path.join(workdir,ref)
		workdir3 = os.path.join(workdir2,ref)
		sp.call('minimap2 -ax splice ' + workdir3 + '_ref.fasta ' + workdir3 +'.fasta > ' + workdir2 + '/align.sam', shell=True)
		sp.call('sam2con.py -i ' + workdir2 + '/align.sam -o ' + workdir2 + ' -p "' + ref + '" -p2 "' + ref + '|' + sample + '"', shell=True)
		if os.path.isfile(workdir3 + '_consensus.fasta'):
			tmp_seq = list(SeqIO.parse(workdir3 + '_consensus.fasta','fasta'))
			for seq in tmp_seq:
				c = seq.seq.count("-")
				l = len(seq.seq)
				if c/l < 0.25:
					output_handle = open(os.path.join(workdir,"{}.fasta".format(ref)),'a')
					SeqIO.write(seq, output_handle, "fasta")
					output_handle.close()
			sp.call('rm -r ' + os.path.join(workdir,ref), shell=True)
		else:
			sp.call('rm -r ' + os.path.join(workdir,ref), shell=True)
		
		sp.call('cat '+ workdir2 + '.fasta >>' + workdir + '.targets.fasta', shell=True)
	
	sp.call('rm -r ' + workdir, shell=True)

def Unambigufy(seq):
	d = {'A': 'A',
		'C': 'C',
		'G': 'G',
		'T': 'T',
		'M': 'AC',
		'R': 'AG',
		'W': 'AT',
		'S': 'CG',
		'Y': 'CT',
		'K': 'GT',
		'V': 'ACG',
		'H': 'ACT',
		'D': 'AGT',
		'B': 'CGT',
		'-': 'N',
		'N': 'N'}
	
	seq2=''
	for letter in seq:
		choice=random.choice(d.get(letter))
		seq2= seq2 + choice
	return seq2

def Phasing(sample, targets_name, folder):
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + sample + ' :::')
	mkdir_p(folder)
	wd=os.path.join(folder,sample)
	ref = list(SeqIO.parse(targets_name,'fasta'))
	new_ref = []
	for rec in ref:
		r = rec
		seq = str(r.seq).upper()
		new_seq = Unambigufy(seq)
		r.seq = Seq(new_seq)
		new_ref.append(r)
	
	handle=open(wd + '.tmp.fasta', "w")
	writer = FastaIO.FastaWriter(handle)
	writer.write_file(new_ref)
	handle.close()

	sp.call('minimap2 -ax sr ' + wd + '.tmp.fasta ' + sample + '*.fastq.gz | samtools sort > ' + wd + '.tmp.bam', shell=True)
	sp.call('samtools index ' + wd + '.tmp.bam', shell=True)
	sp.call('bcftools mpileup -I -f ' + wd + '.tmp.fasta ' + wd + '.tmp.bam | bcftools call -mv -V indels -Oz > ' + wd + '.tmp.vcf.gz', shell=True)
	sp.call('bcftools index ' + wd + '.tmp.vcf.gz', shell=True)
	sp.call('whatshap phase --ignore-read-groups --reference=' + wd + '.tmp.fasta -o ' + wd + '.tmp.phased.vcf ' + wd + '.tmp.vcf.gz ' + wd + '.tmp.bam', shell=True)
	sp.call('bcftools norm -f ' + wd + '.tmp.fasta -m +any -Oz -o ' + wd + '.tmp.phased.norm.vcf.gz ' + wd + '.tmp.phased.vcf', shell=True)
	sp.call('tabix ' + wd + '.tmp.phased.norm.vcf.gz', shell=True)
	sp.call('bcftools consensus -H 1 -f ' + wd + '.tmp.fasta ' + wd + '.tmp.phased.norm.vcf.gz > ' + wd + '.tmp.hap0.fasta', shell=True)
	sp.call('bcftools consensus -H 2 -f ' + wd + '.tmp.fasta ' + wd + '.tmp.phased.norm.vcf.gz > ' + wd + '.tmp.hap1.fasta', shell=True)
	combined_haps = []
	hap0 = list(SeqIO.parse(wd + '.tmp.hap0.fasta','fasta'))
	hap1 = list(SeqIO.parse(wd + '.tmp.hap1.fasta','fasta'))
	for seq in hap0:
		seq.id = seq.name = seq.description = seq.id + "|h0"
		seq.seq = seq.seq.ungap("N")
		combined_haps.append(seq)
	
	for seq in hap1:
		seq.id = seq.name = seq.description = seq.id + "|h1"
		seq.seq = seq.seq.ungap("N")
		combined_haps.append(seq)
	
	sp.call('rm ' + wd + '.tmp.*', shell=True)
	
	handle=open(wd + '.haplotypes.fasta', "w")
	writer = FastaIO.FastaWriter(handle)
	writer.write_file(combined_haps)
	handle.close()


########################################
############ TRANSCRIPTOMES ############
########################################

os.chdir(transcriptomes)

rna_samp_dict = single_or_paired()

## STEP 1 : RUNNING TRINITY

if '1' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 1 ::: Running Trinity Transcriptome Samples :::'
	print(string)
	print('=' * len(string))
	for sample in rna_samp_dict:
		S1_Trinity(sample, rna_samp_dict, '01_trinity')

## STEP 2 : RUNNING CODAN

if '2' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 2 ::: Running CodAn on Trinity Assemblies :::'
	print(string)
	print('=' * len(string))
	for sample in rna_samp_dict:
		S2_CodAn(sample)

## STEP 3 : REMOVING SHORT ISOFORMS

if '3' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 3 ::: Getting longest isoforms :::'
	print(string)
	print('=' * len(string))
	p = mp.Pool(num_threads)
	for sample in rna_samp_dict:
		p.apply_async(S3_LongIsoforms, [sample])
	
	p.close()
	p.join()

## STEP 4 : CLUSTERING FURTHER REDUNDANCY

if '4' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 4 ::: Clustering sequences at 100% identity :::'
	print(string)
	print('=' * len(string))
	p = mp.Pool(num_threads)
	for sample in rna_samp_dict:
		p.apply_async(S4_Cluster, [sample])
	
	p.close()
	p.join()

## STEP 5 : RUNNING ORTHOFINDER

if '5' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 5 ::: Running OrthoFinder :::'
	print(string)
	print('=' * len(string))
	
	sp.call('orthofinder -f 04_clustered -d -og -o 05_orthofinder -t ' + str(num_threads), shell=True)

if '5.5' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 5.5 ::: Sorting OrthoFinder Results :::'
	print(string)
	print('=' * len(string))
	S5_OrthoSorter(rna_samp_dict)

if os.path.isfile('05_orthofinder/single_copy_genes.fasta'):
	cds_targets_name = os.path.abspath('05_orthofinder/single_copy_genes.fasta')
	cds_targets_tmp = list(SeqIO.parse(cds_targets_name,'fasta'))
	
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Removing Orthogroups Matching a Target Locus :::'
	print(string)
	print('=' * len(string))
	if not os.path.isfile(targets_name + ".nin"):
		sp.call('makeblastdb -in ' + targets_name + ' -dbtype nucl', shell=True)
	sp.call('blastn -query ' + cds_targets_name + ' -db ' + targets_name ' -evalue 1e-10 -outfmt 6 -num_threads ' + str(num_threads) + ' > orthogroup_to_target.blast')
	blastfile = pd.read_csv('orthogroup_to_target.blast', sep="\t", names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore'])
	blastfile = list(blastfile['qseqid'])
	cds_targets = []
	unique_ogs = []
	for seq in cds_targets_tmp:
		if seq.id not in blastfile:
			cds_targets.append(seq)
			unique_ogs.append(seq.id.split("|")[0])
	
	handle=open(start_dir + "/prot_coding_targets.fasta", "w")
	writer = FastaIO.FastaWriter(handle)
	writer.write_file(cds_targets)
	handle.close()
	
	print(str(len(unique_ogs)) + " orthogroups are unique from target loci")
	
	
	
	

## STEP 6 : EXTRACTING TARGET LOCI FROM TRANSCRIPTOMES

if '6' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 6 ::: Extracting Target Loci from Transcriptome Assemblies :::'
	print(string)
	print('=' * len(string))
	if not os.path.isfile(targets_name + ".nin"):
		sp.call('makeblastdb -in ' + targets_name + ' -dbtype nucl', shell=True)
	
	p = mp.Pool(num_threads)
	for sample in rna_samp_dict:
		p.apply_async(DistributeContigs, [sample, targets_name,'01_trinity', '06_targets'])
	
	p.close()
	p.join()

## STEP 7 : COMBINING AND PHASING

if '7' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 7 ::: Phasing Consensus Sequences :::'
	print(string)
	print('=' * len(string))
	mkdir_p('07_phasing')
	
	p = mp.Pool(num_threads)
	for sample in rna_samp_dict:
		sp.call('cat 05_orthofinder/' + sample + '.fasta 06_targets/' + sample + '.targets.fasta > 07_phasing/' + sample + '.fasta', shell=True)
		tmp_targets = '07_phasing/' + sample + '.fasta'
		p.apply_async(Phasing, [sample, tmp_targets, '07_phasing'])
	
	p.close()
	p.join()

########################################
########### SEQUENCE CAPTURE ###########
########################################

os.chdir(start_dir)
os.chdir(seqcap)

seqcap_samp_dict = single_or_paired()

## STEP 8 : RUNNING TRINITY ON SEQCAP

if '8' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 8 ::: Running Trinity on SeqCap Samples :::'
	print(string)
	print('=' * len(string))
	for sample in seqcap_samp_dict:
		S1_Trinity(sample, seqcap_samp_dict, '08_trinity')

## STEP 9 : EXTRACTING TRANSCRIPTS FROM SEQCAP DATA

if '9' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 9 ::: Extracting Transcripts from SeqCap Assemblies :::'
	print(string)
	print('=' * len(string))
	
	p = mp.Pool(num_threads)
	for sample in seqcap_samp_dict:
		p.apply_async(DistributeContigs3, [sample, cds_targets_name, '08_trinity', '09_transcripts'])
	
	p.close()
	p.join()

## STEP 10 : EXTRACTING TARGETS FROM SEQCAP DATA

if '10' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 10 ::: Extracting Target Loci from SeqCap Assemblies :::'
	print(string)
	print('=' * len(string))
	if not os.path.isfile(targets_name + ".nin"):
		sp.call('makeblastdb -in ' + targets_name + ' -dbtype nucl', shell=True)
	
	p = mp.Pool(num_threads)
	for sample in seqcap_samp_dict:
		p.apply_async(DistributeContigs, [sample, targets_name, '08_trinity', '10_targets'])
	
	p.close()
	p.join()

## STEP 11 : COMBINING AND PHASING

if '11' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 11 ::: Phasing Consensus Sequences :::'
	print(string)
	print('=' * len(string))
	mkdir_p('11_phasing')
	p = mp.Pool(num_threads)
	for sample in seqcap_samp_dict:
		sp.call('cat 09_transcripts/' + sample + '.targets.fasta 10_targets/' + sample + '.targets.fasta > 11_phasing/' + sample + '.fasta', shell=True)
		tmp_targets = '11_phasing/' + sample + '.fasta'
		p.apply_async(Phasing, [sample, tmp_targets, '11_phasing'])
	
	p.close()
	p.join()

########################################
########### OTHER ASSEMBLIES ###########
########################################

os.chdir(start_dir)
os.chdir(assemblies)

other_assemblies = []
for file in glob.glob('*.fasta'):
	other_assemblies.append(file.split('.')[0])

## STEP 12 : EXTRACTING TRANSCRIPTS FROM OTHER ASSEMBLIES

if '12' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 12 ::: Extracting Transcripts from Other Assemblies :::'
	print(string)
	print('=' * len(string))
	#if not os.path.isfile(cds_targets_name + ".nin"):
	#	sp.call('makeblastdb -in ' + cds_targets_name + ' -dbtype nucl', shell=True)
	
	p = mp.Pool(num_threads)
	for sample in other_assemblies:
		p.apply_async(DistributeContigs3, [sample, cds_targets_name, '.', '12_transcripts'])
	
	p.close()
	p.join()

## STEP 13 : EXTRACTING TARGETS FROM OTHER ASSEMBLIES

if '13' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 13 ::: Extracting Target Loci from Other Assemblies :::'
	print(string)
	print('=' * len(string))
	#if not os.path.isfile(targets_name + ".nin"):
	#	sp.call('makeblastdb -in ' + targets_name + ' -dbtype nucl', shell=True)
	
	p = mp.Pool(num_threads)
	for sample in other_assemblies:
		p.apply_async(DistributeContigs3, [sample, targets_name, '.', '13_targets'])
	
	p.close()
	p.join()

## STEP 14 : COMBINING AND PHASING

if '14' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 14 ::: Phasing Consensus Sequences :::'
	print(string)
	print('=' * len(string))
	mkdir_p('14_phasing')
	p = mp.Pool(num_threads)
	for sample in other_assemblies:
		sp.call('cat 12_transcripts/' + sample + '.targets.fasta 13_targets/' + sample + '.targets.fasta > 11_phasing/' + sample + '.fasta', shell=True)
		tmp_targets = '14_phasing/' + sample + '.fasta'
		p.apply_async(Phasing, [sample, tmp_targets, '14_phasing'])
	
	p.close()
	p.join()

########################################
############### COMBINE ################
########################################

os.chdir(start_dir)

if '15' in steps:
	string='\n'+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Step 15 ::: Consolidate Loci Across Datasets :::'
	print(string)
	print('=' * len(string))
	mkdir_p('16_combined')
	full_sample_list = []
	full_locus_list = []
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: concat transcriptomes :::')
	for sample in rna_samp_dict:
		full_sample_list.append(sample)
		sp.call('cat Transcriptomes/07_phasing/' + sample + '.haplotypes.fasta >> 16_combined/all_loci.fasta', shell=True)
	
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: concat seqcap :::')
	for sample in seqcap_samp_dict:
		full_sample_list.append(sample)
		sp.call('cat SeqCap/11_phasing/' + sample + '.haplotypes.fasta >> 16_combined/all_loci.fasta', shell=True)
	
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: concat other :::')
	for sample in other_assemblies:
		full_sample_list.append(sample)
		sp.call('cat Other/14_phasing/' + sample + '.haplotypes.fasta >> 16_combined/all_loci.fasta', shell=True)
	
	#print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: parse loci :::')
	all_loci = list(SeqIO.parse('16_combined/all_loci.fasta','fasta'))
	for rec in all_loci:
		tmp_rec = []
		locus = rec.id.split('|')[0]
		sample = rec.id.split('|')[1:]
		sample = '|'.join(sample)
		rec.id = rec.description = rec.name = sample
		if locus not in full_locus_list:
			full_locus_list.append(locus)
		tmp_rec.append(rec)
		wd = os.path.join('16_combined',locus)
		mkdir_p(wd)
		handle=open(wd + '/' + locus + '.fasta', "a")
		writer = FastaIO.FastaWriter(handle, wrap=None)
		writer.write_file(tmp_rec)
		handle.close()
	
	for rec in targets:
		tmp_rec = []
		locus = rec.id.split('|')[0]
		sample = rec.id.split('|')[1:]
		sample = '|'.join(sample)
		rec.id = rec.description = rec.name = sample
		if locus in full_locus_list:
			tmp_rec.append(rec)
			wd = os.path.join('16_combined',locus)
			mkdir_p(wd)
			handle=open(wd + '/' + locus + '.fasta', "a")
			writer = FastaIO.FastaWriter(handle, wrap=None)
			writer.write_file(tmp_rec)
			handle.close()


#parallel -a loci.list -j 8 'echo {}
#	mkdir {}
#	mv {}.fasta {}
#	cd {}
#	mafft --auto {}.fasta > {}.aln
#	trimal -in {}.aln -out {}.aln.trimmed -automated1
#	iqtree -s {}.aln.trimmed -bb 1000 -seed 12345'
#
#for i in `cat loci.list`
#	do echo $i
#	cat $i/$i.aln.trimmed.contree >> gene_trees.newick
#	done
#
#java -jar ~/Dropbox/bin/Astral/astral.5.6.3.jar


