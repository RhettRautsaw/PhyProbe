#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
#import pathos.multiprocessing as mp
import multiprocessing as mp
import random
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
except:
	print("Error: biopython module is not properly installed.")
	quit()

try:
	import numpy as np
except:
	print("Error: numpy is not properly installed.")
	quit()

try:
	import pandas as pd
	import matplotlib.pyplot as plt
except:
	print("Error: pandas is not properly installed.")
	quit()

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Sort multi-fasta into individual loci and get tally of number of samples per locus and number of loci per sample.

Assumes targets have the format:
>target_name|genus_species

But delimiter | can be changed with the -d flag.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-f","--fasta",
					type=str,
					default='squamate_AHE_UCE_genes_loci2.fasta',
					help="Concatenated fasta with all loci (default: %(default)s)")
parser.add_argument("-d","--delim",
					type=str,
					default='|',
					help="Delimiter used to separate target/gene names from sample names (default: %(default)s)")
parser.add_argument("-c","--cutoff",
					type=int,
					default=500,
					help="Minimum number of loci needed in a given sample (default: %(default)s)")
parser.add_argument("-p","--percent",
					type=int,
					default=50,
					help="Percent missing data allowed. (default: %(default)s)")
parser.add_argument("-o","--output",
					type=str,
					default='00_PhyProbeLoci',
					help="Folder to export results (default: %(default)s)")
args=parser.parse_args()

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

########################################
################# CODE #################
########################################

fasta_name = os.path.abspath(args.fasta)
delim=args.delim
percent=args.percent/100
cutoff=args.cutoff
output=os.path.abspath(args.output)

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting Sort and Tally...")
print("\tLoci -> "+ args.fasta)
print("\tDelim -> "+ delim)
print("\tPercent -> "+str(args.percent)+"%")
print("\tOutput -> "+ output)

mkdir_p(output + "/all_loci")
mkdir_p(output + "/cleaned")
all_loci = list(SeqIO.parse(fasta_name,'fasta'))

samples=[]
loci=[]

for rec in all_loci:
	locus = rec.id.split(delim)[0]
	sample1 = rec.id.split(delim)[1]
	if sample1 not in samples:
		samples.append(sample1)
	if locus not in loci:
		loci.append(locus)

print("Identified " + str(len(samples)) + " samples and " + str(len(loci)) + " loci")
print("Tabulating locus/sample presence and removing loci/samples with more than " + str(args.percent) + "% missing data")

df = pd.DataFrame(0,index=loci, columns=samples)

for rec in all_loci:
	locus = rec.id.split(delim)[0]
	sample1 = rec.id.split(delim)[1]
	df[sample1][locus]=df[sample1][locus]+1

# Removing samples without minimum number of loci before filtering by %.
# Samples with little coverage across any loci can artificially decrease percentage.
tmp_sum=df.sum(axis=0).to_frame(name="vals")
bad_samples=list(tmp_sum[(tmp_sum['vals'] < cutoff)].index)
df2=df.drop(columns=bad_samples)
print("Removing " + str(len(bad_samples)) + " samples that did not meet the minimum number of loci required " + str(cutoff))

# Sample coverage per locus
tmp_means=df2.mean(axis=1).to_frame(name="vals")
bad_loci=list(tmp_means[(tmp_means['vals'] < percent)].index)
df3=df2.drop(bad_loci)
print("Removing " + str(len(bad_loci)) + " loci that had greater than " + str(args.percent) + "% missing data")

# Locus coverage per sample
tmp_means2=df3.mean(axis=1).to_frame(name="vals")
bad_samples2=list(tmp_means2[(tmp_means2['vals'] < percent)].index)
df4=df3.drop(columns=bad_samples2)
print("Removing " + str(len(bad_samples2)) + " additional samples that had greater than " + str(args.percent) + "% missing data")

bad_samples=bad_samples + bad_samples2

for rec in all_loci:
	locus = rec.id.split(delim)[0]
	sample1 = rec.id.split(delim)[1:]
	sample2 = '|'.join(sample1)
	rec.id = rec.description = rec.name = sample2
	
	## ALL LOCI
	tmp_rec = []
	tmp_rec.append(rec)
	
	prefix = os.path.join(output,"all_loci",locus)
	handle=open(prefix + '.fasta', "a")
	writer = FastaIO.FastaWriter(handle, wrap=None)
	writer.write_file(tmp_rec)
	handle.close()
	
	## CLEANED LOCI
	tmp_rec = []
	if locus not in bad_loci and sample1[0] not in bad_samples:
		tmp_rec.append(rec)
		
		prefix = os.path.join(output,"cleaned",locus)
		handle=open(prefix + '.fasta', "a")
		writer = FastaIO.FastaWriter(handle, wrap=None)
		writer.write_file(tmp_rec)
		handle.close()

with open(os.path.join(output,'bad_samples.txt'), 'w') as filehandle:
	for listitem in bad_samples:
		filehandle.write('%s\n' % listitem)

with open(os.path.join(output,'bad_loci.txt'), 'w') as filehandle:
	for listitem in bad_loci:
		filehandle.write('%s\n' % listitem)

og_samp_cov=df.mean(axis=0).to_frame(name="vals")
og_loci_cov=df.mean(axis=1).to_frame(name="vals")
clean_samp_cov=df4.mean(axis=0).to_frame(name="vals")
clean_loci_cov=df4.mean(axis=1).to_frame(name="vals")

og_samp_cov.to_csv(os.path.join(output,'all_loci_sample_coverage.csv'))
og_loci_cov.to_csv(os.path.join(output,'all_loci_loci_coverage.csv'))
clean_samp_cov.to_csv(os.path.join(output,'cleaned_sample_coverage.csv'))
clean_loci_cov.to_csv(os.path.join(output,'cleaned_loci_coverage.csv'))