#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
#import pathos.multiprocessing as mp
import multiprocessing as mp
import random
import pysam
import pyfastx
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
	from Bio.SeqIO.QualityIO import FastqGeneralIterator
except:
	print("Error: biopython module is not properly installed.")
	quit()

try:
	import numpy as np
except:
	print("Error: numpy is not properly installed.")
	quit()

try:
	import pandas as pd
except:
	print("Error: pandas is not properly installed.")
	quit()

try:
	from dfply import *
except:
	print("Error: dfply is not properly installed.")
	quit()

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Phaser
Map reads, find SNPs, phase SNPs, extract consensus sequences

Assumes targets have the format:
>target_name|genus_species

But delimiter | can be changed with the -d flag.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-r","--reads",
					nargs='+',
					#default='sample1_R1.fastq.gz sample1_R2.fastq.gz',
					default=[],
					help="Space-separated list of reads in fastq(.gz) format (default: %(default)s)")
parser.add_argument("-t","--targets",
					type=str,
					default='../squamate_AHE_UCE_genes_loci2.fasta',
					help="Reference fasta with target loci (default: %(default)s)")
parser.add_argument("-d","--delim",
					type=str,
					default='|',
					help="Delimiter used to separate target/gene names from sample names (default: %(default)s)")
parser.add_argument("-p","--prefix",
					type=str,
					#default='sample1',
					default='I0796_Daboia_russelii',
					help="Unique name of sample for output (default: %(default)s)")
parser.add_argument("-o","--output",
					type=str,
					default="00_phase",
					help="Folder in which to export results (default: %(default)s)")
parser.add_argument("-c","--cpu",
					type=int,
					default=8,
					help="Number of threads to be used in each step. (default: %(default)s)")
args=parser.parse_args()

########################################
################# SETUP ################
########################################

reads = [os.path.abspath(x) for x in args.reads]

#tmp = args.reads.split(",")
#reads=[]
#for i in tmp:
#	files=glob.glob(i)
#	for j in files:
#		reads.append(os.path.abspath(j))
#
#reads=reads.sort()

targets_name = os.path.abspath(args.targets)
delim = args.delim
prefix = args.prefix
output = args.output
num_threads = args.cpu

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting Phaser...")
start_dir = os.getcwd()
print("\tReads -> "+ ' '.join(reads))
print("\tTargets -> "+ targets_name)
print("\tPrefix -> "+ prefix)
print("\tOutput -> "+ output)
print("\tThreads -> "+ str(num_threads))

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

def Unambigufy(seq):
	d = {'A': 'A',
		'C': 'C',
		'G': 'G',
		'T': 'T',
		'M': 'AC',
		'R': 'AG',
		'W': 'AT',
		'S': 'CG',
		'Y': 'CT',
		'K': 'GT',
		'V': 'ACG',
		'H': 'ACT',
		'D': 'AGT',
		'B': 'CGT',
		'-': 'N',
		'N': 'N'}
	
	seq2=''
	for letter in seq:
		choice=random.choice(d.get(letter))
		seq2= seq2 + choice
	return seq2

########################################
################# CODE #################
########################################

print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: ' + prefix + ' :::')
wd = os.path.join(output,prefix) # output/prefix
prefix2 = os.path.join(wd,prefix) # output/prefix/prefix
mkdir_p(wd)

targets = list(SeqIO.parse(targets_name,'fasta'))

# REMOVE AMBIGUITIES FOR PHASING
new_ref = []
for rec in targets:
	r = rec
	seq = str(r.seq).upper()
	new_seq = Unambigufy(seq)
	r.seq = Seq(new_seq)
	new_ref.append(r)

handle=open(prefix2 + '.tmp.fasta', "w")
writer = FastaIO.FastaWriter(handle)
writer.write_file(new_ref)
handle.close()

sp.call('minimap2 -ax sr -t ' + str(num_threads) + ' ' + prefix2 + '.tmp.fasta ' + ' '.join(reads) + ' | samtools sort -@ ' + str(num_threads) + ' - > ' + prefix2 + '.tmp.bam', shell=True)
sp.call('samtools index ' + prefix2 + '.tmp.bam', shell=True)
sp.call('bcftools mpileup -I -f ' + prefix2 + '.tmp.fasta ' + prefix2 + '.tmp.bam | bcftools call -mv -V indels -Oz > ' + prefix2 + '.tmp.vcf.gz', shell=True)
sp.call('bcftools index ' + prefix2 + '.tmp.vcf.gz', shell=True)
sp.call('whatshap phase --ignore-read-groups --reference=' + prefix2 + '.tmp.fasta -o ' + prefix2 + '.tmp.phased.vcf ' + prefix2 + '.tmp.vcf.gz ' + prefix2 + '.tmp.bam', shell=True)
sp.call('bcftools norm -f ' + prefix2 + '.tmp.fasta -m +any -Oz -o ' + prefix2 + '.tmp.phased.norm.vcf.gz ' + prefix2 + '.tmp.phased.vcf', shell=True)
sp.call('tabix ' + prefix2 + '.tmp.phased.norm.vcf.gz', shell=True)
sp.call('bcftools consensus -H 1 -f ' + prefix2 + '.tmp.fasta ' + prefix2 + '.tmp.phased.norm.vcf.gz > ' + prefix2 + '.tmp.hap0.fasta', shell=True)
sp.call('bcftools consensus -H 2 -f ' + prefix2 + '.tmp.fasta ' + prefix2 + '.tmp.phased.norm.vcf.gz > ' + prefix2 + '.tmp.hap1.fasta', shell=True)
combined_haps = []
hap0 = list(SeqIO.parse(prefix2 + '.tmp.hap0.fasta','fasta'))
hap1 = list(SeqIO.parse(prefix2 + '.tmp.hap1.fasta','fasta'))
for seq in hap0:
	seq.id = seq.name = seq.description = seq.id + "|h0"
	seq.seq = seq.seq.ungap("N")
	combined_haps.append(seq)

for seq in hap1:
	seq.id = seq.name = seq.description = seq.id + "|h1"
	seq.seq = seq.seq.ungap("N")
	combined_haps.append(seq)

#sp.call('rm ' + prefix2 + '.tmp.*', shell=True)

handle=open(wd + '.haplotypes.fasta', "w")
writer = FastaIO.FastaWriter(handle)
writer.write_file(combined_haps)
handle.close()
