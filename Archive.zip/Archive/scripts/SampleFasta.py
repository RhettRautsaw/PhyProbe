#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
except:
	print("Error: biopython module is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Extracts one sequence per locus for searches

Assumes targets have the format:
>target_name|genus_species

But delimiter | can be changed with the -d flag.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-q","--query",
					type=str,
					default='protein_coding_targets.tmp.fasta',
					help="Reference fasta with orthofinder single copy loci (default: %(default)s)")
parser.add_argument("-d","--delim",
					type=str,
					default='|',
					help="Delimiter used to separate target/gene names from sample names (default: %(default)s)")
args=parser.parse_args()

########################################
################# CODE #################
########################################

query_name = os.path.abspath(args.query)
query_name2=query_name.split("/")[-1]
query_name2=query_name2.split(".")[0]
delim=args.delim

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: Reading in Data...")
query = list(SeqIO.parse(query_name,'fasta'))

loci=[]
new_fasta=[]

for seq in query:
	locus=seq.name.split(delim)[0]
	if locus not in loci:
		loci.append(locus)
		new_fasta.append(seq)

handle=open(query_name2 + "_reduced.fasta", "w")
writer = FastaIO.FastaWriter(handle)
writer.write_file(new_fasta)
handle.close()