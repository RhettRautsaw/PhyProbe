#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import multiprocessing as mp

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Rename BUSCO Sequences.

Assumes targets have the format:
>locus_name|sample_name

But delimiter | can be changed with the -d flag.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-f","--folder",
					type=str,
					default='single_copy_busco_sequences',
					help="Folder with busco_sequences (default: %(default)s)")
parser.add_argument("-n","--name",
					type=str,
					default='sample1',
					help="Name to apply to sequence (default: %(default)s)")
parser.add_argument("-d","--delim",
					type=str,
					default='|',
					help="Delimiter used to separate locus names from sample names (default: %(default)s)")
parser.add_argument("-c","--cpu",
					type=int,
					default=8,
					help="Number of threads to be used in each step. (default: %(default)s)")
args=parser.parse_args()

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

def Renamer(locus):
	locus_name=locus.split('/')[-1]
	locus_name=locus_name.split(".fna")[0]
	sp.call("sed 's/>.*/>" + locus_name + "\\" + delim + name + "/g' " + locus + " > " + os.path.join(output,locus_name) + ".fasta", shell=True)

########################################
################# CODE #################
########################################

folder=os.path.abspath(args.folder)
output=folder+"_renamed"
name = args.name
delim = args.delim
num_threads = args.cpu

mkdir_p(output)

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting BUSCO_sorter...")
print("\tBUSCO Sequences -> "+ folder)
print("\tName to Apply -> "+ name)
print("\tDelim -> "+ delim)
print("\tThreads -> "+ str(num_threads))
print("\tOutput Folder -> "+ output)

p = mp.Pool(num_threads)
for locus in glob.glob(folder + '/*.fna'):
	p.apply_async(Renamer, [locus])

p.close()
p.join()
