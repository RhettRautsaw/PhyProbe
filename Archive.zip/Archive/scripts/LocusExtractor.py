#!/usr/bin/env python3

import sys, os, shutil, errno
import datetime as dt
import argparse
from argparse import RawTextHelpFormatter
import csv
import subprocess as sp
import gzip
#import pathos.multiprocessing as mp
import multiprocessing as mp
import random
import pysam
import pyfastx
from tqdm import tqdm
try:
	from Bio import SeqIO
	from Bio.Seq import Seq
	from Bio.SeqRecord import SeqRecord
	from Bio.SeqIO import FastaIO
	from Bio.SeqIO.QualityIO import FastqGeneralIterator
except:
	print("Error: biopython module is not properly installed.")
	quit()

try:
	import numpy as np
except:
	print("Error: numpy is not properly installed.")
	quit()

try:
	import pandas as pd
except:
	print("Error: pandas is not properly installed.")
	quit()

try:
	from dfply import *
except:
	print("Error: dfply is not properly installed.")
	quit()

try:
	import glob
except:
	print("Error: glob is not properly installed.")
	quit()

#prefix="Abili-I2064_SeqCap_unknown"
#delim="|"
#targets_name=os.path.abspath("../squamate_AHE_UCE_genes_loci2.fasta")
#output='06_targets'
#reads=[os.path.abspath(x) for x in glob.glob("*.fastq.gz")]
#percent=0.25
#num_threads=16
#bam=True

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter, description="""

Distribute reads to targets, assemble, and extract consensus.

Assumes targets have the format:
>target_name|genus_species

But delimiter | can be changed with the -d flag.

""")

########################################
############### ARGUMENTS ##############
########################################

parser.add_argument("-r","--reads",
					nargs='+',
					#default='sample1_R1.fastq.gz sample1_R2.fastq.gz',
					default=[],
					help="Space-separated list of reads in fastq(.gz) format (default: %(default)s)")
parser.add_argument("-t","--targets",
					type=str,
					default='../squamate_AHE_UCE_genes_loci2.fasta',
					help="Reference fasta with target loci (default: %(default)s)")
parser.add_argument("-d","--delim",
					type=str,
					default='|',
					help="Delimiter used to separate target/gene names from sample names (default: %(default)s)")
parser.add_argument("-p","--prefix",
					type=str,
					#default='sample1',
					default='Abili-CLP2469_RNA_VG',
					help="Unique name of sample for output (default: %(default)s)")
parser.add_argument("-o","--output",
					type=str,
					default="06_targets",
					help="Folder in which to export results (default: %(default)s)")
parser.add_argument("--percent",
					type=int,
					default=25,
					help="Percent missing data (gaps) allowed in a locus. (default: %(default)s)")
parser.add_argument("--bam",
					action="store_true",
					default=False,
					help="Use mapping with minimap2 instead of blast search")
parser.add_argument("-c","--cpu",
					type=int,
					default=8,
					help="Number of threads to be used in each step. (default: %(default)s)")
args=parser.parse_args()

########################################
################# SETUP ################
########################################

reads = [os.path.abspath(x) for x in args.reads]

#tmp = args.reads.split(",")
#reads=[]
#for i in tmp:
#	files=glob.glob(i)
#	for j in files:
#		reads.append(os.path.abspath(j))
#
#reads.sort()

targets_name = os.path.abspath(args.targets)
delim = args.delim
prefix = args.prefix
output = args.output
percent = args.percent/100
bam = args.bam
num_threads = args.cpu

print("\n"+dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+" ::: starting LociExtractor...")
start_dir = os.getcwd()
print("\tReads -> "+ ' '.join(reads))
print("\tTargets -> "+ targets_name)
print("\tPrefix -> "+ prefix)
print("\tOutput -> "+ output)
print("\tPercent -> "+ str(percent))
print("\tThreads -> "+ str(num_threads))
print("\tUsing Mapping -> "+ str(bam))

########################################
############### FUNCTIONS ##############
########################################

def mkdir_p(path):
	try:
		os.makedirs(path)
	except OSError as exc: # Python >2.5
		if exc.errno == errno.EEXIST and os.path.isdir(path):
			pass
		else: raise

def chunks(lst, n):
	"""Yield successive n-sized chunks from lst."""
	for i in range(0, len(lst), n):
		yield lst[i:i + n]

def ReadDistributor(ref):
	# DEFINE REFERENCE WORKING DIRECTORIES AND PREFIX
	ref_wd = os.path.join(wd,ref) # output/prefix/ref
	ref_prefix = os.path.join(ref_wd, ref) # output/prefix/ref/ref
	
	# CREATE DIRECTORY FOR EACH REFERENCE, SUBSET ALIGNFILE, DETERMINE BEST REF, 
	mkdir_p(ref_wd)
	sub_blast = alignfile >> mask(X.ref == ref)
	best_ref = list((sub_blast >> arrange(X.score, X.length, ascending=False) >> head(1)).sseqid)
	
	# EXTRACT BEST TARGET SEQ
	for seq in targets:
		if seq.id in best_ref:
			output_handle = open(ref_prefix + '_ref.fasta','a')
			SeqIO.write(seq, output_handle, "fasta")
			output_handle.close()
	
	if bam: 
		sub_qseqid= list(sub_blast.qseqid)
		sub_seqs = list(sub_blast.seq)
		sub_qseqid2=[">"+x for x in sub_qseqid]
		new_fasta=[val for pair in zip(sub_qseqid2, sub_seqs) for val in pair]
		new_fasta_df=pd.DataFrame(new_fasta,columns=[''])
		new_fasta_df.to_csv(ref_prefix + '_reads.fasta',index=None, header=None)
	else:
		fa = pyfastx.Fasta(sub_reads)
		sub_qseqid = list(sub_blast.qseqid.unique())
		for read in sub_qseqid:
			seq=fa[read].seq
			outfile = open(ref_prefix + '_reads.fasta','a')
			outfile.write(">{}\n{}\n".format(read,seq))
			outfile.close()

def Assembler(ref, percent):
	# DEFINE REFERENCE WORKING DIRECTORIES AND PREFIX
	ref_wd = os.path.join(wd,ref) # output/prefix/ref
	ref_prefix = os.path.join(ref_wd, ref) # output/prefix/ref/ref
	
	sp.call("spades.py --only-assembler --threads 1 --cov-cutoff 8 -s " + ref_prefix + "_reads.fasta -o " + os.path.join(ref_wd,"spades"), shell=True)
	if os.path.isfile(os.path.join(ref_wd,"spades/contigs.fasta")):
		sp.call("mv " + os.path.join(ref_wd,"spades/contigs.fasta") + " " + ref_prefix + "_contigs.fasta", shell=True)
	else:
		sp.call("mv " + ref_prefix + "_reads.fasta" + " " + ref_prefix + "_contigs.fasta", shell=True)
	sp.call('minimap2 -ax splice ' + ref_prefix + "_ref.fasta " + ref_prefix + "_contigs.fasta > " + os.path.join(ref_wd,"align.sam"), shell=True)
	sp.call('sam2con.py -i ' + os.path.join(ref_wd,"align.sam") + ' -o ' + ref_wd + ' -p "' + ref + '" -p2 "' + ref + '|' + prefix + '"', shell=True)
	if os.path.isfile(ref_prefix + '_consensus.fasta'):
		tmp_seq = list(SeqIO.parse(ref_prefix + '_consensus.fasta','fasta'))
		for seq in tmp_seq:
			c = seq.seq.count("-")
			l = len(seq.seq)
			if c/l < percent:
				output_handle = open(ref_wd + ".fasta",'a')
				SeqIO.write(seq, output_handle, "fasta")
				output_handle.close()
			else:
				sp.call('rm -r ' + os.path.join(ref_wd), shell=True)
	else:
		sp.call('rm -r ' + os.path.join(ref_wd), shell=True)
	
	sp.call('cat '+ ref_wd + '.fasta >> ' + wd + '.targets.fasta', shell=True)

########################################
################# CODE #################
########################################

wd = os.path.join(output,prefix) # output/prefix
prefix2 = os.path.join(wd,prefix) # output/prefix/prefix
mkdir_p(wd)

targets = list(SeqIO.parse(targets_name,'fasta'))
all_refs = set([seq.id.split(delim)[0] for seq in targets])

all_reads = prefix2 + ".combined.fastq"
all_reads2 = prefix2 + ".combined.fasta"
sub_reads=prefix2 + ".mapped.fasta"

# CONCATENATE READS TOGETHER
print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Concatenating Read Files :::')

sp.call("rm " + all_reads, shell=True)
for file in reads:
	if '.gz' in file:
		sp.call("zcat " + file + " >> " + all_reads, shell=True)
	else:
		sp.call("cat "  + file + " >> " + all_reads, shell=True)


# ALIGN READS TO TARGET FILE
if bam:
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Aligning Reads to Targets :::')
	sp.call("minimap2 -ax sr -t " + str(num_threads) + " " + targets_name + " " + all_reads + " | samtools sort -@ 16 - | samtools view -@ 16 -F 4 - | grep -v '^@' - > " + prefix2 + ".sam", shell=True)
	alignfile = pd.read_csv(prefix2 + ".sam", sep="\t", names=['qseqid', 'flag', 'sseqid', 'pos', 'score', 'cigar', 'rnext', 'pnext', 'length', 'seq', 'qual'], index_col=False, usecols=range(11))
else:
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Converting Fastq to Fasta :::')
	sp.call("seqtk seq -a " + all_reads + " > " + all_reads2, shell=True)
	print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Aligning Reads to Targets :::')
	sp.call("blastn -query " + all_reads2 + " -db " + targets_name + " -max_target_seqs 10 -evalue 1e-10 -outfmt 6 -num_threads " + str(num_threads) + " > " + prefix2 + ".blast", shell=True)
	alignfile = pd.read_csv(prefix2 + ".blast", sep="\t", names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'sstart', 'send', 'evalue', 'score'])
	sp.call("cut -f1 " + prefix2 + ".blast > " + prefix2 + "_map.list", shell=True)
	sp.call("seqtk subseq " + all_reads + " " + prefix2 + "_map.list | seqtk seq -a - > " + sub_reads, shell=True)
	fa = pyfastx.Fasta(sub_reads)

# PARSE BLAST/BAM RESULTS
print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Parsing Reads and Targets to Folders :::')

alignfile = alignfile >> mutate(tmp = X.sseqid) >> separate(X.tmp, ['ref'], sep="\\"+delim)
refs = list(alignfile.ref.unique())
print(prefix + ": " + str(len(alignfile)) + " read hits representing " + str(len(refs)) + " of " + str(len(all_refs)) + " targets have hits")

ref_chunks=list(chunks(refs, 100))

for sub_list in tqdm(ref_chunks):
	p = mp.Pool(num_threads)
	for ref in sub_list:
		p.apply_async(ReadDistributor, [ref])
	
	p.close()
	p.join()

sp.call("rm " + all_reads + " " + all_reads2, shell=True)


# RUN SPADES ASSEMBLY AND SCAFFOLD (REMOVING GAPS).
print(dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ' ::: Assembling and Extracting Consensus Sequences :::')

for sub_list in tqdm(ref_chunks):
	p = mp.Pool(num_threads)
	for ref in sub_list:
		p.apply_async(Assembler, [ref, percent])
	
	p.close()
	p.join()

